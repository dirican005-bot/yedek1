import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import MainLayout from "./components/layout/MainLayout";
import Dashboard from "./pages/Dashboard";
import Vardiyalar from "./pages/Vardiyalar";
import TahsilatOdeme from "./pages/TahsilatOdeme";
import CariVeresiye from "./pages/CariVeresiye";
import GelirGider from "./pages/GelirGider";
import Faturalar from "./pages/Faturalar";
import Personel from "./pages/Personel";
import KasaYonetimi from "./pages/KasaYonetimi";
import StokTanklar from "./pages/StokTanklar";
import CanliSatis from "./pages/CanliSatis";
import Raporlar from "./pages/Raporlar";
import Ayarlar from "./pages/Ayarlar";
import Kullanicilar from "./pages/Kullanicilar";

function Router() {
  return (
    <MainLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/vardiyalar" component={Vardiyalar} />
        <Route path="/tahsilat" component={TahsilatOdeme} />
        <Route path="/cari" component={CariVeresiye} />
        <Route path="/gelir-gider" component={GelirGider} />
        <Route path="/faturalar" component={Faturalar} />
        <Route path="/personel" component={Personel} />
        <Route path="/kasa" component={KasaYonetimi} />
        <Route path="/stok" component={StokTanklar} />
        <Route path="/canli-satis" component={CanliSatis} />
        <Route path="/raporlar" component={Raporlar} />
        <Route path="/ayarlar" component={Ayarlar} />
        <Route path="/kullanicilar" component={Kullanicilar} />
      </Switch>
    </MainLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
