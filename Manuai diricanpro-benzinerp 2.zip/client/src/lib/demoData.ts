// DiricanPro BenzinERP - Demo Veri Seti
// Tüm modüller için gerçekçi demo veriler

export const demoStats = {
  gunlukSatisTutari: 245630,
  gunlukSatisLitre: 12450.78,
  veresiyeToplam: 35418.90,
  nakitKasaBakiye: 120000,
  gunlukIslemSayisi: 286,
  oncekiGunSatisTutari: 198540,
  oncekiGunSatisLitre: 9850.32,
  cariSayisi: 118,
  bankaBakiye: 48500,
};

export const yakitTurleri = ['MOTORİN', 'BENZİN', 'LPG', 'GAZ YAĞI'];

export const pompalar = [
  { id: 1, no: '01', aktif: true, urun: 'MOTORİN', litre: 3125.45, tutar: 62450.00 },
  { id: 2, no: '02', aktif: true, urun: 'LPG', litre: 2985.20, tutar: 59840.00 },
  { id: 3, no: '03', aktif: true, urun: 'MOTORİN', litre: 3030.13, tutar: 60780.00 },
  { id: 4, no: '04', aktif: true, urun: 'BENZİN', litre: 3330.00, tutar: 66560.00 },
];

export const tanklar = [
  { id: 1, no: 'TANK 1', urun: 'MOTORİN', stok: 12560, kapasite: 20000, yuzde: 62, renk: '#3B82F6' },
  { id: 2, no: 'TANK 2', urun: 'MOTORİN', stok: 8420, kapasite: 20000, yuzde: 42, renk: '#3B82F6' },
  { id: 3, no: 'TANK 3', urun: 'LPG', stok: 6230, kapasite: 8000, yuzde: 78, renk: '#F59E0B' },
  { id: 4, no: 'TANK 4', urun: 'BENZİN', stok: 2910, kapasite: 10000, yuzde: 29, renk: '#EF4444' },
];

export const urunDagilim = [
  { urun: 'MOTORİN', litre: 8125.45, renk: '#3B82F6' },
  { urun: 'LPG', litre: 3000.00, renk: '#F59E0B' },
  { urun: 'BENZİN', litre: 1000.13, renk: '#22C55E' },
  { urun: 'GAZ YAĞI', litre: 325.20, renk: '#8B5CF6' },
];

export const haftalikSatis = [
  { gun: 'Pzt', tutar: 180500 },
  { gun: 'Sal', tutar: 195760 },
  { gun: 'Çar', tutar: 210430 },
  { gun: 'Per', tutar: 198540 },
  { gun: 'Cum', tutar: 230100 },
  { gun: 'Cmt', tutar: 320150 },
  { gun: 'Paz', tutar: 245630 },
];

export const tahsilatDurumu = [
  { aralik: '0-30 Gün', tutar: 12450, renk: '#22C55E' },
  { aralik: '31-60 Gün', tutar: 9800, renk: '#F59E0B' },
  { aralik: '61-90 Gün', tutar: 7325, renk: '#EF4444' },
  { aralik: '90+ Gün', tutar: 5983, renk: '#8B5CF6' },
];

export const odemeTipleri = [
  { tip: 'Nakit', tutar: 98650, yuzde: 40.18, ikon: '💵' },
  { tip: 'Visa/Master', tutar: 87420, yuzde: 35.50, ikon: '💳' },
  { tip: 'Banka', tutar: 54650, yuzde: 22.27, ikon: '🏦' },
  { tip: 'Veresiye', tutar: 5910, yuzde: 2.41, ikon: '📋' },
];

export const canliSatislar = [
  { saat: '16:25:35', plaka: '34 ABC 123', pompa: '01', urun: 'MOTORİN', litre: 40, tutar: 1600, odemeTipi: 'Nakit', personel: 'Ahmet YILMAZ' },
  { saat: '16:24:55', plaka: '06 DEF 456', pompa: '02', urun: 'LPG', litre: 32, tutar: 640, odemeTipi: 'Nakit', personel: 'Mehmet KAYA' },
  { saat: '16:23:48', plaka: '35 GHI 789', pompa: '03', urun: 'MOTORİN', litre: 45, tutar: 1800, odemeTipi: 'Nakit', personel: 'Caner ŞAHİN' },
  { saat: '16:22:33', plaka: '33 JKL 012', pompa: '03', urun: 'MOTORİN', litre: 30, tutar: 1200, odemeTipi: 'Visa', personel: 'Ali DEMİR' },
  { saat: '16:21:44', plaka: '07 MNO 345', pompa: '02', urun: 'LPG', litre: 40, tutar: 800, odemeTipi: 'Nakit', personel: 'Fatma YILDIZ' },
  { saat: '16:20:15', plaka: '16 PQR 678', pompa: '04', urun: 'MOTORİN', litre: 50, tutar: 2000, odemeTipi: 'Visa', personel: 'Mehmet KAYA' },
  { saat: '16:19:31', plaka: '34 STU 901', pompa: '03', urun: 'BENZİN', litre: 30, tutar: 1150, odemeTipi: 'Nakit', personel: 'Ahmet YILMAZ' },
  { saat: '16:18:22', plaka: '06 VXY 234', pompa: '04', urun: 'MOTORİN', litre: 47, tutar: 1880, odemeTipi: 'Nakit', personel: 'Caner ŞAHİN' },
  { saat: '16:17:18', plaka: '09 ZAB 567', pompa: '02', urun: 'LPG', litre: 28, tutar: 560, odemeTipi: 'Nakit', personel: 'Ali DEMİR' },
  { saat: '16:16:05', plaka: '34 CDE 890', pompa: '04', urun: 'MOTORİN', litre: 35, tutar: 1400, odemeTipi: 'Visa', personel: 'Fatma YILDIZ' },
];

export const vardiyalar = [
  { tarih: '18.05.2025', vardiya: 'Gündüz', acilis: '06:00', kapanis: '14:05', toplamSatis: 145230, litre: 7385.40, durum: 'Kapalı' },
  { tarih: '18.05.2025', vardiya: 'Gece', acilis: '14:05', kapanis: '23:59', toplamSatis: 100400, litre: 5065.38, durum: 'Kapalı' },
  { tarih: '17.05.2025', vardiya: 'Gündüz', acilis: '06:00', kapanis: '14:00', toplamSatis: 132540, litre: 6780.25, durum: 'Kapalı' },
  { tarih: '17.05.2025', vardiya: 'Gece', acilis: '14:00', kapanis: '23:59', toplamSatis: 98700, litre: 4985.10, durum: 'Kapalı' },
  { tarih: '16.05.2025', vardiya: 'Gündüz', acilis: '06:00', kapanis: '14:02', toplamSatis: 140230, litre: 7150.20, durum: 'Kapalı' },
  { tarih: '16.05.2025', vardiya: 'Gece', acilis: '14:02', kapanis: '23:59', toplamSatis: 96200, litre: 4800.00, durum: 'Kapalı' },
  { tarih: '15.05.2025', vardiya: 'Gündüz', acilis: '06:00', kapanis: '14:00', toplamSatis: 130800, litre: 6520.30, durum: 'Kapalı' },
];

export const cariler = [
  { id: 'C00015', ad: 'YILDIRIM NAKLİYAT', telefon: '0532 123 45 67', bakiye: 4450, borc: 12450, alacak: 8000, limit: 20000, aktif: true },
  { id: 'C00023', ad: 'KARTAL İNŞAAT', telefon: '0533 234 56 78', bakiye: 2300, borc: 8900, alacak: 6600, limit: 15000, aktif: true },
  { id: 'C00031', ad: 'ANADOLU LOJİSTİK', telefon: '0534 345 67 89', bakiye: 7800, borc: 15600, alacak: 7800, limit: 25000, aktif: true },
  { id: 'C00042', ad: 'GÜNEŞ TAŞIMACILIK', telefon: '0535 456 78 90', bakiye: 1200, borc: 5400, alacak: 4200, limit: 10000, aktif: true },
  { id: 'C00055', ad: 'BARAN TİCARET', telefon: '0536 567 89 01', bakiye: 9500, borc: 18000, alacak: 8500, limit: 30000, aktif: true },
  { id: 'C00063', ad: 'KAYA AKARYAKIT', telefon: '0537 678 90 12', bakiye: 3400, borc: 9800, alacak: 6400, limit: 20000, aktif: false },
];

export const cariEkstre = [
  { tarih: '18.05.2025', aciklama: 'Akaryakıt Satışı', borc: 5000, alacak: 0, bakiye: 4450 },
  { tarih: '18.05.2025', aciklama: 'Tahsilat', borc: 0, alacak: 3500, bakiye: -550 },
  { tarih: '17.05.2025', aciklama: 'Akaryakıt Satışı', borc: 4000, alacak: 0, bakiye: 2950 },
  { tarih: '17.05.2025', aciklama: 'Ödeme', borc: 0, alacak: 2000, bakiye: -1050 },
  { tarih: '16.05.2025', aciklama: 'Akaryakıt Satışı', borc: 6000, alacak: 0, bakiye: 950 },
  { tarih: '16.05.2025', aciklama: 'Ödeme', borc: 0, alacak: 1500, bakiye: -5050 },
];

export const personeller = [
  { id: 1, ad: 'Ahmet YILMAZ', gorev: 'Pompa', telefon: '0532 123 45 67', girisTarihi: '01.02.2021', durum: 'Aktif' },
  { id: 2, ad: 'Mehmet KAYA', gorev: 'Pompa', telefon: '0533 987 65 43', girisTarihi: '15.03.2020', durum: 'Aktif' },
  { id: 3, ad: 'Caner ŞAHİN', gorev: 'Vardiya Amiri', telefon: '0535 543 21 09', girisTarihi: '10.06.2021', durum: 'Aktif' },
  { id: 4, ad: 'Ali DEMİR', gorev: 'Pompa', telefon: '0531 111 22 33', girisTarihi: '01.07.2023', durum: 'Aktif' },
  { id: 5, ad: 'Fatma YILDIZ', gorev: 'Kasiyer', telefon: '0538 222 33 44', girisTarihi: '05.04.2023', durum: 'Aktif' },
];

export const kasaHareketleri = [
  { tarih: '18.05.2025', tur: 'Giriş', aciklama: 'Gün Sonu Nakit', giris: 98650, cikis: 0, bakiye: 120000, kullanici: 'Admin' },
  { tarih: '18.05.2025', tur: 'Çıkış', aciklama: 'Market Alış', giris: 0, cikis: 3500, bakiye: 21350, kullanici: 'Admin' },
  { tarih: '18.05.2025', tur: 'Çıkış', aciklama: 'Kredi Kartı Tahsilat', giris: 0, cikis: 0, bakiye: 24850, kullanici: 'Admin' },
  { tarih: '18.05.2025', tur: 'Giriş', aciklama: 'Banka Havale', giris: 5000, cikis: 0, bakiye: 25000, kullanici: 'Admin' },
];

export const gelirGiderler = [
  { tarih: '18.05.2025', tur: 'Gider', aciklama: 'Elektrik Faturası', tutar: 5000 },
  { tarih: '18.05.2025', tur: 'Gider', aciklama: 'Su Faturası', tutar: 1200 },
  { tarih: '18.05.2025', tur: 'Gelir', aciklama: 'Market Satış', tutar: 3300 },
  { tarih: '17.05.2025', tur: 'Gider', aciklama: 'Personel Maaş', tutar: 8000 },
  { tarih: '17.05.2025', tur: 'Gider', aciklama: 'Akaryakıt Alış', tutar: 0 },
];

export const tahsilatlar = [
  { tarih: '18.05.2025', tur: 'Tahsilat', tutar: 3500, odemeTipi: 'Nakit' },
  { tarih: '18.05.2025', tur: 'Tahsilat', tutar: 2000, odemeTipi: 'Visa' },
  { tarih: '17.05.2025', tur: 'Tahsilat', tutar: 5000, odemeTipi: 'Banka' },
  { tarih: '16.05.2025', tur: 'Ödeme', tutar: 1500, odemeTipi: 'Nakit' },
  { tarih: '15.05.2025', tur: 'Tahsilat', tutar: 5000, odemeTipi: 'Banka' },
];

export const hizliIstatistik = {
  ortalamaLitreSatis: 43.53,
  ortalamaTutarSatis: 858.85,
  enCokSatilanUrun: 'MOTORİN',
  enCokSatanPompa: '04',
  enYogunSaat: '15:00 - 16:00',
  toplamMusteriGun: 182,
};

export const stokHareketleri = [
  { tarih: '18.05.2025', tank: 'Tank 1', urun: 'Motorin', islem: 'Satış', miktar: -5000, kalan: 15035 },
  { tarih: '18.05.2025', tank: 'Tank 2', urun: 'Motorin', islem: 'Satış', miktar: -1590, kalan: 8420 },
  { tarih: '18.05.2025', tank: 'Tank 3', urun: 'LPG', islem: 'Dolum', miktar: 8000, kalan: 6230 },
];

export const formatTutar = (tutar: number): string => {
  return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(tutar) + ' ₺';
};

export const formatLitre = (litre: number): string => {
  return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(litre) + ' LT';
};
