import { useState } from "react";
import { cariler, cariEkstre, formatTutar } from "@/lib/demoData";
import { Plus, FileText, MessageSquare, Download } from "lucide-react";
import { toast } from "sonner";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function CariVeresiye() {
  const [selectedCari, setSelectedCari] = useState(cariler[0]);
  const [aramaMetni, setAramaMetni] = useState('');

  const filtreliCariler = cariler.filter(c =>
    c.ad.toLowerCase().includes(aramaMetni.toLowerCase()) ||
    c.id.toLowerCase().includes(aramaMetni.toLowerCase())
  );

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        {/* Cari Listesi */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="4" title="Cari / Veresiye Listesi" color="#1E6FD9">
            <button className="erp-btn-primary flex items-center gap-1" onClick={() => toast.info('Yeni cari ekleniyor')}>
              <Plus size={12} />Yeni Cari
            </button>
          </PanelHeader>
          <div className="p-2">
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                className="erp-input"
                placeholder="Cari ara..."
                value={aramaMetni}
                onChange={e => setAramaMetni(e.target.value)}
                style={{ flex: 1 }}
              />
              <input type="date" className="erp-input" defaultValue="2025-05-01" />
              <input type="date" className="erp-input" defaultValue="2025-05-18" />
              <button className="erp-btn-primary">Listele</button>
            </div>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Cari Kodu</th>
                  <th>Ad / Unvan</th>
                  <th>Telefon</th>
                  <th className="text-right">Borç</th>
                  <th className="text-right">Alacak</th>
                  <th className="text-right">Bakiye</th>
                  <th>Durum</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody>
                {filtreliCariler.map((c, i) => (
                  <tr key={i} style={{ cursor: 'pointer', backgroundColor: selectedCari?.id === c.id ? '#1a2e4a' : undefined }}
                    onClick={() => setSelectedCari(c)}>
                    <td style={{ color: '#60A5FA', fontWeight: 600 }}>{c.id}</td>
                    <td style={{ color: '#E2E8F0', fontWeight: 500 }}>{c.ad}</td>
                    <td style={{ color: '#94A3B8' }}>{c.telefon}</td>
                    <td className="text-right mono" style={{ color: '#EF4444', fontWeight: 600 }}>{c.borc.toLocaleString('tr-TR')} ₺</td>
                    <td className="text-right mono" style={{ color: '#22C55E' }}>{c.alacak.toLocaleString('tr-TR')} ₺</td>
                    <td className="text-right mono" style={{ color: c.bakiye > 0 ? '#F59E0B' : '#22C55E', fontWeight: 700 }}>
                      {c.bakiye.toLocaleString('tr-TR')} ₺
                    </td>
                    <td><span className={c.aktif ? 'erp-badge-green' : 'erp-badge-red'}>{c.aktif ? 'Aktif' : 'Pasif'}</span></td>
                    <td>
                      <div className="flex gap-1">
                        <button onClick={() => toast.info('Ekstre görüntüleniyor')} style={{ background: 'none', border: 'none', color: '#60A5FA', cursor: 'pointer' }}>
                          <FileText size={13} />
                        </button>
                        <button onClick={() => toast.info('SMS gönderildi')} style={{ background: 'none', border: 'none', color: '#22C55E', cursor: 'pointer' }}>
                          <MessageSquare size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={3} style={{ fontWeight: 700, color: '#E2E8F0', fontSize: '11px' }}>Toplam</td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#EF4444' }}>
                    {cariler.reduce((s, c) => s + c.borc, 0).toLocaleString('tr-TR')} ₺
                  </td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#22C55E' }}>
                    {cariler.reduce((s, c) => s + c.alacak, 0).toLocaleString('tr-TR')} ₺
                  </td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#F59E0B' }}>
                    {cariler.reduce((s, c) => s + c.bakiye, 0).toLocaleString('tr-TR')} ₺
                  </td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Cari Ekstre */}
        {selectedCari && (
          <div className="erp-panel" style={{ width: '340px', minWidth: '340px' }}>
            <PanelHeader num="4" title="Cari / Veresiye Ekstre" color="#F59E0B">
              <button className="erp-btn-primary" style={{ fontSize: '10px', padding: '2px 8px' }} onClick={() => toast.info('Ekstre yazdırılıyor')}>
                <FileText size={11} className="inline mr-1" />Ekstre Yaz
              </button>
              <button className="erp-btn-primary" style={{ fontSize: '10px', padding: '2px 8px', backgroundColor: '#22C55E' }} onClick={() => toast.info('SMS gönderildi')}>
                <MessageSquare size={11} className="inline mr-1" />SMS
              </button>
              <button className="erp-btn-primary" style={{ fontSize: '10px', padding: '2px 8px', backgroundColor: '#16a34a' }} onClick={() => toast.info('Excel aktarılıyor')}>
                <Download size={11} className="inline mr-1" />Excel
              </button>
            </PanelHeader>
            <div className="p-2">
              <div className="flex gap-2 mb-2">
                <select className="erp-select" style={{ flex: 1, fontSize: '11px' }}>
                  <option>{selectedCari.id} - {selectedCari.ad}</option>
                </select>
              </div>
              <div className="flex gap-2 mb-2">
                <input type="date" className="erp-input" defaultValue="2025-05-01" style={{ flex: 1 }} />
                <input type="date" className="erp-input" defaultValue="2025-05-18" style={{ flex: 1 }} />
                <button className="erp-btn-primary">Listele</button>
              </div>
              <table className="erp-table w-full">
                <thead>
                  <tr>
                    <th>Tarih</th>
                    <th>Açıklama</th>
                    <th className="text-right">Borç</th>
                    <th className="text-right">Alacak</th>
                    <th className="text-right">Bakiye</th>
                  </tr>
                </thead>
                <tbody>
                  {cariEkstre.map((e, i) => (
                    <tr key={i}>
                      <td style={{ color: '#94A3B8' }}>{e.tarih}</td>
                      <td style={{ color: '#CBD5E1' }}>{e.aciklama}</td>
                      <td className="text-right mono" style={{ color: e.borc > 0 ? '#EF4444' : '#94A3B8' }}>
                        {e.borc > 0 ? e.borc.toLocaleString('tr-TR') : '-'}
                      </td>
                      <td className="text-right mono" style={{ color: e.alacak > 0 ? '#22C55E' : '#94A3B8' }}>
                        {e.alacak > 0 ? e.alacak.toLocaleString('tr-TR') : '-'}
                      </td>
                      <td className="text-right mono" style={{ color: e.bakiye > 0 ? '#F59E0B' : '#22C55E', fontWeight: 600 }}>
                        {Math.abs(e.bakiye).toLocaleString('tr-TR')} ₺
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div style={{ borderTop: '1px solid #1E3A5F', paddingTop: '6px', marginTop: '4px' }}>
                <div className="flex justify-between">
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>Toplam Borç</span>
                  <span style={{ fontSize: '11px', color: '#EF4444', fontWeight: 700, fontFamily: 'Roboto Mono, monospace' }}>
                    {selectedCari.borc.toLocaleString('tr-TR')} ₺
                  </span>
                </div>
                <div className="flex justify-between">
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>Toplam Alacak</span>
                  <span style={{ fontSize: '11px', color: '#22C55E', fontWeight: 700, fontFamily: 'Roboto Mono, monospace' }}>
                    {selectedCari.alacak.toLocaleString('tr-TR')} ₺
                  </span>
                </div>
                <div className="flex justify-between" style={{ paddingTop: '4px', borderTop: '1px solid #1E3A5F', marginTop: '4px' }}>
                  <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0' }}>Bakiye</span>
                  <span style={{ fontSize: '13px', fontWeight: 700, color: '#F59E0B', fontFamily: 'Roboto Mono, monospace' }}>
                    {selectedCari.bakiye.toLocaleString('tr-TR')} ₺
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
