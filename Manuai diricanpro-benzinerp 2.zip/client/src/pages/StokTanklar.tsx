import { tanklar, stokHareketleri } from "@/lib/demoData";
import { toast } from "sonner";
import { Plus } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function StokTanklar() {
  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {/* Tank Kartları */}
      <div className="flex gap-2">
        {tanklar.map((t, i) => {
          const barColor = t.yuzde < 30 ? '#EF4444' : t.yuzde < 50 ? '#F59E0B' : '#22C55E';
          return (
            <div key={i} className="erp-panel" style={{ flex: 1 }}>
              <PanelHeader num={`T${i + 1}`} title={`${t.no} - ${t.urun}`} color={barColor} />
              <div className="p-3">
                <div style={{ fontSize: '24px', fontWeight: 700, color: barColor, fontFamily: 'Roboto Mono, monospace', marginBottom: '4px' }}>
                  {t.stok.toLocaleString('tr-TR')} LT
                </div>
                <div style={{ fontSize: '10px', color: '#94A3B8', marginBottom: '8px' }}>
                  Kapasite: {t.kapasite.toLocaleString('tr-TR')} LT
                </div>
                <div style={{ height: '20px', backgroundColor: '#0B1426', borderRadius: '4px', overflow: 'hidden', border: '1px solid #1E3A5F', marginBottom: '4px' }}>
                  <div style={{ width: `${t.yuzde}%`, height: '100%', backgroundColor: barColor, borderRadius: '3px', transition: 'width 0.5s' }} />
                </div>
                <div className="flex justify-between">
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>Doluluk</span>
                  <span style={{ fontSize: '12px', fontWeight: 700, color: barColor }}>%{t.yuzde}</span>
                </div>
                <button className="erp-btn-primary w-full mt-3" style={{ fontSize: '11px' }}
                  onClick={() => toast.info(`${t.no} dolum işlemi başlatıldı`)}>
                  Dolum Ekle
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stok Hareketleri */}
      <div className="flex gap-2">
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="8" title="Stok / Tank Hareketleri" color="#F59E0B">
            <button className="erp-btn-primary flex items-center gap-1" onClick={() => toast.info('Yeni stok hareketi')}>
              <Plus size={12} />Yeni Hareket
            </button>
          </PanelHeader>
          <div className="p-2">
            <div className="flex gap-2 mb-2">
              <input type="date" className="erp-input" defaultValue="2025-05-01" />
              <input type="date" className="erp-input" defaultValue="2025-05-18" />
              <select className="erp-select">
                <option value="">Tüm Tanklar</option>
                {tanklar.map(t => <option key={t.id}>{t.no}</option>)}
              </select>
              <select className="erp-select">
                <option value="">Tüm İşlemler</option>
                <option>Satış</option>
                <option>Dolum</option>
                <option>Sayım</option>
              </select>
              <button className="erp-btn-primary">Listele</button>
            </div>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Tarih</th>
                  <th>Tank</th>
                  <th>Ürün</th>
                  <th>İşlem</th>
                  <th className="text-right">Miktar (LT)</th>
                  <th className="text-right">Kalan (LT)</th>
                </tr>
              </thead>
              <tbody>
                {stokHareketleri.map((s, i) => (
                  <tr key={i}>
                    <td style={{ color: '#94A3B8' }}>{s.tarih}</td>
                    <td style={{ color: '#60A5FA', fontWeight: 600 }}>{s.tank}</td>
                    <td style={{ color: '#CBD5E1' }}>{s.urun}</td>
                    <td><span className={s.islem === 'Dolum' ? 'erp-badge-green' : 'erp-badge-blue'}>{s.islem}</span></td>
                    <td className="text-right mono" style={{ color: s.miktar < 0 ? '#EF4444' : '#22C55E', fontWeight: 600 }}>
                      {s.miktar > 0 ? '+' : ''}{s.miktar.toLocaleString('tr-TR')}
                    </td>
                    <td className="text-right mono" style={{ color: '#E2E8F0' }}>{s.kalan.toLocaleString('tr-TR')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Dolum Formu */}
        <div className="erp-panel" style={{ width: '240px', minWidth: '240px' }}>
          <PanelHeader num="8" title="Dolum Ekle" color="#22C55E" />
          <div className="p-3">
            <div className="flex flex-col gap-2">
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tank *</label>
                <select className="erp-select w-full mt-1">
                  {tanklar.map(t => <option key={t.id}>{t.no} - {t.urun}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tarih *</label>
                <input type="date" className="erp-input w-full mt-1" defaultValue="2025-05-18" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Miktar (LT) *</label>
                <input type="number" className="erp-input w-full mt-1" placeholder="0" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Birim Fiyat (₺)</label>
                <input type="number" className="erp-input w-full mt-1" placeholder="0,00" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tedarikçi</label>
                <input type="text" className="erp-input w-full mt-1" placeholder="Tedarikçi adı" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Açıklama</label>
                <input type="text" className="erp-input w-full mt-1" placeholder="Açıklama" />
              </div>
              <button className="erp-btn-success w-full mt-2" onClick={() => toast.success('Dolum kaydedildi!')}>
                Dolum Kaydet
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
