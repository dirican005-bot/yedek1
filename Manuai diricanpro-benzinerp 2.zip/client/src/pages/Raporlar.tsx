import { haftalikSatis, urunDagilim, odemeTipleri } from "@/lib/demoData";
import { toast } from "sonner";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend
} from "recharts";
import { Download, Printer } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

const aylikData = [
  { ay: 'Ocak', satis: 180500, litre: 5580, musteri: 1820 },
  { ay: 'Şubat', satis: 195760, litre: 6050, musteri: 1950 },
  { ay: 'Mart', satis: 210430, litre: 6510, musteri: 2100 },
  { ay: 'Nisan', satis: 198540, litre: 6140, musteri: 1980 },
  { ay: 'Mayıs', satis: 245630, litre: 7590, musteri: 2450 },
];

export default function Raporlar() {
  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {/* Rapor Seçenekleri */}
      <div className="erp-panel">
        <PanelHeader num="📊" title="Raporlar & Dashboard" color="#1E6FD9">
          <button className="erp-btn-primary flex items-center gap-1" onClick={() => toast.info('Rapor indiriliyor')}>
            <Download size={12} />Excel İndir
          </button>
          <button className="erp-btn-primary flex items-center gap-1" style={{ backgroundColor: '#6B7280' }} onClick={() => toast.info('Yazdırılıyor')}>
            <Printer size={12} />Yazdır
          </button>
        </PanelHeader>
        <div className="p-2 flex gap-2 flex-wrap">
          {[
            'Günlük Satış Raporu', 'Vardiya Raporu', 'Cari Hesap Raporu',
            'Stok/Tank Raporu', 'Kasa Raporu', 'Personel Raporu',
            'Gelir/Gider Raporu', 'Kar/Zarar Raporu', 'Aylık Özet'
          ].map((r, i) => (
            <button key={i} className="erp-btn-primary" style={{ fontSize: '11px' }}
              onClick={() => toast.info(`${r} hazırlanıyor...`)}>
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Grafikler */}
      <div className="flex gap-2">
        {/* Aylık Satış Trendi */}
        <div className="erp-panel" style={{ flex: 2 }}>
          <PanelHeader num="📈" title="Aylık Satış Trendi" color="#22C55E" />
          <div className="p-2">
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={aylikData} margin={{ top: 4, right: 16, bottom: 0, left: 0 }}>
                <XAxis dataKey="ay" tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip
                  contentStyle={{ backgroundColor: '#152642', border: '1px solid #1E3A5F', fontSize: '11px', color: '#E2E8F0' }}
                  formatter={(v: any) => [v.toLocaleString('tr-TR') + ' ₺', 'Satış']}
                />
                <Line type="monotone" dataKey="satis" stroke="#22C55E" strokeWidth={2} dot={{ fill: '#22C55E', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Ürün Dağılım */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="🥧" title="Ürün Satış Dağılımı" color="#3B82F6" />
          <div className="p-2 flex items-center justify-center">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={urunDagilim} dataKey="litre" cx="50%" cy="50%" outerRadius={70} paddingAngle={3} label={({ urun, yuzde }: any) => `${urun}`}>
                  {urunDagilim.map((entry, i) => (
                    <Cell key={i} fill={entry.renk} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#152642', border: '1px solid #1E3A5F', fontSize: '11px', color: '#E2E8F0' }}
                  formatter={(v: any) => [v.toLocaleString('tr-TR') + ' LT']}
                />
                <Legend wrapperStyle={{ fontSize: '10px', color: '#94A3B8' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Aylık Özet Tablo */}
      <div className="erp-panel">
        <PanelHeader num="📋" title="Aylık Özet Tablo" color="#F59E0B" />
        <div className="p-2">
          <table className="erp-table w-full">
            <thead>
              <tr>
                <th>Ay</th>
                <th className="text-right">Satış Tutarı</th>
                <th className="text-right">Satış Litre</th>
                <th className="text-right">Müşteri Sayısı</th>
                <th className="text-right">Ort. Tutar/Satış</th>
                <th className="text-right">Ort. Litre/Satış</th>
              </tr>
            </thead>
            <tbody>
              {aylikData.map((a, i) => (
                <tr key={i}>
                  <td style={{ color: '#E2E8F0', fontWeight: 600 }}>{a.ay}</td>
                  <td className="text-right mono" style={{ color: '#22C55E', fontWeight: 600 }}>{a.satis.toLocaleString('tr-TR')} ₺</td>
                  <td className="text-right mono" style={{ color: '#3B82F6' }}>{a.litre.toLocaleString('tr-TR')} LT</td>
                  <td className="text-right mono" style={{ color: '#94A3B8' }}>{a.musteri.toLocaleString('tr-TR')}</td>
                  <td className="text-right mono" style={{ color: '#E2E8F0' }}>{(a.satis / a.musteri).toFixed(0)} ₺</td>
                  <td className="text-right mono" style={{ color: '#E2E8F0' }}>{(a.litre / a.musteri * 1000).toFixed(1)} LT</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td style={{ fontWeight: 700, color: '#E2E8F0' }}>TOPLAM</td>
                <td className="text-right mono" style={{ fontWeight: 700, color: '#22C55E' }}>
                  {aylikData.reduce((s, a) => s + a.satis, 0).toLocaleString('tr-TR')} ₺
                </td>
                <td className="text-right mono" style={{ fontWeight: 700, color: '#3B82F6' }}>
                  {aylikData.reduce((s, a) => s + a.litre, 0).toLocaleString('tr-TR')} LT
                </td>
                <td className="text-right mono" style={{ fontWeight: 700, color: '#94A3B8' }}>
                  {aylikData.reduce((s, a) => s + a.musteri, 0).toLocaleString('tr-TR')}
                </td>
                <td colSpan={2} />
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}
