import { useState } from "react";
import { vardiyalar, tanklar, pompalar, formatTutar, formatLitre } from "@/lib/demoData";
import { Eye, Edit, Printer, X, Plus } from "lucide-react";
import { toast } from "sonner";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F',
    borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function Vardiyalar() {
  const [selectedVardiya, setSelectedVardiya] = useState(vardiyalar[0]);
  const [activeTab, setActiveTab] = useState('satis');
  const [vardiyaAcik, setVardiyaAcik] = useState(false);

  const tabs = ['SATIŞ ÖZETİ', 'TAHSİLAT', 'KASA HAREKETLERİ', 'POMPA SATIŞ', 'PERSONEL'];

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        {/* Kapalı Vardiya Listesi */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="2" title="Kapalı Vardiya Listesi" color="#1E6FD9">
            <button className="erp-btn-primary" onClick={() => toast.info('Yeni vardiya kaydı')}>
              <Plus size={12} className="inline mr-1" />Yeni Kayıt
            </button>
          </PanelHeader>
          <div className="p-2">
            <div className="flex gap-2 mb-2">
              <input type="date" className="erp-input" defaultValue="2025-05-01" style={{ fontSize: '11px' }} />
              <input type="date" className="erp-input" defaultValue="2025-05-18" style={{ fontSize: '11px' }} />
              <select className="erp-select" style={{ fontSize: '11px' }}>
                <option value="tumu">Vardiya Türü: Tümü</option>
                <option>Gündüz</option>
                <option>Gece</option>
              </select>
              <button className="erp-btn-primary">Listele</button>
            </div>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Tarih</th>
                  <th>Vardiya</th>
                  <th>Açılış</th>
                  <th>Kapanış</th>
                  <th className="text-right">Toplam Satış</th>
                  <th className="text-right">Litre</th>
                  <th>Durum</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody>
                {vardiyalar.map((v, i) => (
                  <tr key={i} style={{ cursor: 'pointer', backgroundColor: selectedVardiya === v ? '#1a2e4a' : undefined }}
                    onClick={() => setSelectedVardiya(v)}>
                    <td style={{ color: '#CBD5E1' }}>{v.tarih}</td>
                    <td><span className={v.vardiya === 'Gündüz' ? 'erp-badge-yellow' : 'erp-badge-blue'}>{v.vardiya}</span></td>
                    <td className="mono" style={{ color: '#94A3B8' }}>{v.acilis}</td>
                    <td className="mono" style={{ color: '#94A3B8' }}>{v.kapanis}</td>
                    <td className="text-right mono" style={{ color: '#22C55E', fontWeight: 600 }}>{v.toplamSatis.toLocaleString('tr-TR')} ₺</td>
                    <td className="text-right mono" style={{ color: '#94A3B8' }}>{v.litre.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</td>
                    <td><span className="erp-badge-red">{v.durum}</span></td>
                    <td>
                      <div className="flex gap-1">
                        <button onClick={() => toast.info('Detay görüntüleniyor')} style={{ background: 'none', border: 'none', color: '#60A5FA', cursor: 'pointer' }}><Eye size={13} /></button>
                        <button onClick={() => toast.info('Düzenleme modu')} style={{ background: 'none', border: 'none', color: '#F59E0B', cursor: 'pointer' }}><Edit size={13} /></button>
                        <button onClick={() => toast.info('Yazdırılıyor')} style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer' }}><Printer size={13} /></button>
                        <button onClick={() => toast.info('Silindi')} style={{ background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}><X size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={4} style={{ fontWeight: 700, color: '#E2E8F0', fontSize: '11px' }}>Toplam</td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#22C55E' }}>
                    {vardiyalar.reduce((s, v) => s + v.toplamSatis, 0).toLocaleString('tr-TR')} ₺
                  </td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#E2E8F0' }}>
                    {vardiyalar.reduce((s, v) => s + v.litre, 0).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                  </td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Vardiya Detayı */}
        <div className="erp-panel" style={{ width: '320px', minWidth: '320px' }}>
          <PanelHeader num="" title="Vardiya Detayı" color="#22C55E" />
          <div className="p-2">
            <div className="flex gap-2 mb-2" style={{ fontSize: '11px', color: '#94A3B8' }}>
              <span>Vardiya: <strong style={{ color: '#E2E8F0' }}>18.05.2025 - Gündüz</strong></span>
            </div>
            <div className="flex gap-1 mb-2">
              <span style={{ fontSize: '10px', color: '#94A3B8' }}>Açılış: <strong style={{ color: '#60A5FA' }}>06:00</strong></span>
              <span style={{ fontSize: '10px', color: '#94A3B8', marginLeft: '8px' }}>Kapanış: <strong style={{ color: '#60A5FA' }}>14:05</strong></span>
            </div>

            {/* Tabs */}
            <div className="flex gap-1 mb-2" style={{ flexWrap: 'wrap' }}>
              {tabs.map(t => (
                <button key={t} onClick={() => setActiveTab(t.toLowerCase())}
                  style={{
                    fontSize: '9px', fontWeight: 700, padding: '3px 6px', borderRadius: '3px', border: 'none', cursor: 'pointer',
                    backgroundColor: activeTab === t.toLowerCase() ? '#1E6FD9' : '#152642',
                    color: activeTab === t.toLowerCase() ? 'white' : '#94A3B8',
                  }}>
                  {t}
                </button>
              ))}
            </div>

            {/* Satış Özeti */}
            <div>
              <div style={{ fontSize: '10px', fontWeight: 700, color: '#94A3B8', marginBottom: '4px' }}>ÜRÜN</div>
              {[
                { urun: 'MOTORİN', litre: 4895.40, tutar: 98780 },
                { urun: 'LPG', litre: 1760, tutar: 35200 },
                { urun: 'BENZİN', litre: 580, tutar: 10150 },
                { urun: 'GAZ YAĞI', litre: 150, tutar: 1172 },
              ].map((u, i) => (
                <div key={i} className="flex justify-between mb-1">
                  <span style={{ fontSize: '11px', color: '#CBD5E1' }}>{u.urun}</span>
                  <span style={{ fontSize: '11px', color: '#94A3B8', fontFamily: 'Roboto Mono, monospace' }}>{u.litre.toLocaleString('tr-TR')}</span>
                  <span style={{ fontSize: '11px', color: '#22C55E', fontFamily: 'Roboto Mono, monospace' }}>{u.tutar.toLocaleString('tr-TR')} ₺</span>
                </div>
              ))}
              <div style={{ borderTop: '1px solid #1E3A5F', paddingTop: '4px', marginTop: '4px' }}>
                <div className="flex justify-between">
                  <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0' }}>TOPLAM</span>
                  <span style={{ fontSize: '11px', fontWeight: 700, color: '#3B82F6', fontFamily: 'Roboto Mono, monospace' }}>7.385,40</span>
                  <span style={{ fontSize: '11px', fontWeight: 700, color: '#22C55E', fontFamily: 'Roboto Mono, monospace' }}>145.230,00 ₺</span>
                </div>
              </div>

              <div style={{ marginTop: '8px', borderTop: '1px solid #1E3A5F', paddingTop: '6px' }}>
                <div className="flex justify-between mb-1">
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>NAKİT</span>
                  <span style={{ fontSize: '11px', color: '#22C55E', fontFamily: 'Roboto Mono, monospace' }}>63.520,00 ₺</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>VİSA/MASTER</span>
                  <span style={{ fontSize: '11px', color: '#3B82F6', fontFamily: 'Roboto Mono, monospace' }}>52.480,00 ₺</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>BANKA</span>
                  <span style={{ fontSize: '11px', color: '#8B5CF6', fontFamily: 'Roboto Mono, monospace' }}>27.730,00 ₺</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>VERESİYE</span>
                  <span style={{ fontSize: '11px', color: '#F59E0B', fontFamily: 'Roboto Mono, monospace' }}>1.500,00 ₺</span>
                </div>
                <div style={{ borderTop: '1px solid #1E3A5F', paddingTop: '4px', marginTop: '4px' }}>
                  <div className="flex justify-between">
                    <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0' }}>FARK</span>
                    <span style={{ fontSize: '12px', fontWeight: 700, color: '#22C55E' }}>0,00 ₺ (DENGE OK)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Vardiya Aç/Kapat */}
      <div className="flex gap-2">
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="10" title="Vardiya Aç / Kapat" color="#22C55E" />
          <div className="p-3 flex gap-4">
            {/* Vardiya Aç */}
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '11px', fontWeight: 700, color: '#22C55E', marginBottom: '8px' }}>VARDIYA AÇ</div>
              <div className="flex flex-col gap-2">
                <div>
                  <label style={{ fontSize: '10px', color: '#94A3B8' }}>Personel</label>
                  <select className="erp-select w-full mt-1">
                    <option>Ahmet YILMAZ</option>
                    <option>Mehmet KAYA</option>
                    <option>Caner ŞAHİN</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '10px', color: '#94A3B8' }}>Vardiya Türü</label>
                  <select className="erp-select w-full mt-1">
                    <option>Gündüz</option>
                    <option>Gece</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '10px', color: '#94A3B8' }}>Açılış Saati</label>
                  <input type="time" className="erp-input w-full mt-1" defaultValue="06:00" />
                </div>
                <div>
                  <label style={{ fontSize: '10px', color: '#94A3B8' }}>Açılış Nakit</label>
                  <input type="number" className="erp-input w-full mt-1" defaultValue="50000" />
                </div>
                <button className="erp-btn-success w-full mt-2" onClick={() => toast.success('Vardiya açıldı!')}>
                  Vardiyayı Aç
                </button>
              </div>
            </div>

            {/* Vardiya Kapat */}
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '11px', fontWeight: 700, color: '#EF4444', marginBottom: '8px' }}>VARDIYA KAPAT</div>
              <div className="flex flex-col gap-1">
                {[
                  { label: 'Açılış Saati', value: '18.05.2025 06:00' },
                  { label: 'Kapanış Saati', value: '18.05.2025 14:05' },
                  { label: 'Toplam Satış', value: '145.230,00 ₺' },
                  { label: 'Toplam Litre', value: '7.385,40 LT' },
                ].map((item, i) => (
                  <div key={i} className="flex justify-between py-1" style={{ borderBottom: '1px solid #1a2e4a' }}>
                    <span style={{ fontSize: '10px', color: '#94A3B8' }}>{item.label}</span>
                    <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 600 }}>{item.value}</span>
                  </div>
                ))}
                <div style={{ marginTop: '8px' }}>
                  <div className="flex justify-between">
                    <span style={{ fontSize: '10px', color: '#94A3B8' }}>Nakit</span>
                    <span style={{ fontSize: '11px', color: '#22C55E', fontWeight: 600 }}>65.020,00 ₺</span>
                  </div>
                  <div className="flex justify-between">
                    <span style={{ fontSize: '10px', color: '#94A3B8' }}>Kasa Toplamı</span>
                    <span style={{ fontSize: '11px', color: '#E2E8F0', fontWeight: 600 }}>146.730,00 ₺</span>
                  </div>
                  <div className="flex justify-between" style={{ marginTop: '4px', paddingTop: '4px', borderTop: '1px solid #1E3A5F' }}>
                    <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0' }}>Fark</span>
                    <span style={{ fontSize: '13px', fontWeight: 700, color: '#22C55E' }}>+1.500,00 ₺</span>
                  </div>
                </div>
                <button className="erp-btn-danger w-full mt-2" onClick={() => toast.warning('Vardiya kapatıldı!')}>
                  Vardiyayı Kapat
                </button>
              </div>
            </div>

            {/* Fark Analizi */}
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '11px', fontWeight: 700, color: '#F59E0B', marginBottom: '8px' }}>FARK ANALİZİ</div>
              {[
                { label: 'Sistem Tutarı', value: '145.230,00 ₺', color: '#E2E8F0' },
                { label: 'Kasa Toplamı', value: '146.730,00 ₺', color: '#E2E8F0' },
                { label: 'Fark', value: '+1.500,00 ₺', color: '#22C55E' },
                { label: 'Açıklama', value: 'Fazla', color: '#F59E0B' },
              ].map((item, i) => (
                <div key={i} className="flex justify-between py-1.5" style={{ borderBottom: '1px solid #1a2e4a' }}>
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>{item.label}</span>
                  <span style={{ fontSize: '11px', color: item.color, fontWeight: 600 }}>{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
