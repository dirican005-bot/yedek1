// Home.tsx - Dashboard'a yönlendirme
import Dashboard from "./Dashboard";
export default Dashboard;
