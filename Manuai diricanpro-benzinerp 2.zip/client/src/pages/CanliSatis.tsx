import { useState, useEffect } from "react";
import { canliSatislar, pompalar, formatTutar } from "@/lib/demoData";
import { toast } from "sonner";
import { RefreshCw, Play, Square, Wifi } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function CanliSatis() {
  const [isLive, setIsLive] = useState(false);
  const [xmlPath, setXmlPath] = useState('\\\\10.102.24.10\\Shift\\Sale.xml');
  const [interval, setIntervalVal] = useState('15');
  const [lastUpdate, setLastUpdate] = useState('--:--:--');
  const [satislar, setSatislar] = useState(canliSatislar);

  const handleStart = () => {
    setIsLive(true);
    setLastUpdate(new Date().toLocaleTimeString('tr-TR'));
    toast.success('Canlı veri çekme başlatıldı!');
  };

  const handleStop = () => {
    setIsLive(false);
    toast.warning('Canlı veri çekme durduruldu!');
  };

  const handleManualRefresh = () => {
    setLastUpdate(new Date().toLocaleTimeString('tr-TR'));
    toast.info('Veriler yenilendi!');
  };

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {/* Bağlantı Ayarları */}
      <div className="erp-panel">
        <PanelHeader num="9" title="Canlı Satış (XML) & Pompa Durumu" color="#22C55E">
          <div className="flex items-center gap-1">
            <div className={isLive ? 'live-dot' : ''} style={!isLive ? { width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#EF4444' } : {}} />
            <span style={{ fontSize: '10px', color: isLive ? '#22C55E' : '#EF4444', fontWeight: 700 }}>
              {isLive ? 'CANLI' : 'DURDURULDU'}
            </span>
          </div>
        </PanelHeader>
        <div className="p-3">
          <div className="flex gap-3 items-end flex-wrap">
            <div>
              <label style={{ fontSize: '10px', color: '#94A3B8' }}>XML Dosya Yolu (Açık Vardiya)</label>
              <input type="text" className="erp-input mt-1" value={xmlPath} onChange={e => setXmlPath(e.target.value)}
                style={{ width: '320px' }} />
            </div>
            <div>
              <label style={{ fontSize: '10px', color: '#94A3B8' }}>Yenileme Aralığı (sn)</label>
              <input type="number" className="erp-input mt-1" value={interval} onChange={e => setIntervalVal(e.target.value)}
                style={{ width: '80px' }} />
            </div>
            <div>
              <label style={{ fontSize: '10px', color: '#94A3B8' }}>Son Güncelleme</label>
              <div className="erp-input mt-1 mono" style={{ width: '100px', color: '#60A5FA' }}>{lastUpdate}</div>
            </div>
            <div className="flex gap-2">
              <button className="erp-btn-success flex items-center gap-1" onClick={handleStart} disabled={isLive}>
                <Play size={12} />XML'den Veri Çek
              </button>
              <button className="erp-btn-primary flex items-center gap-1" onClick={handleManualRefresh}>
                <RefreshCw size={12} />Canlı Yenile ({interval}sn)
              </button>
              <button className="erp-btn-danger flex items-center gap-1" onClick={handleStop}>
                <Square size={12} />Durdur
              </button>
            </div>
          </div>
          <div className="mt-2 p-2 rounded" style={{ backgroundColor: '#0B1426', border: '1px solid #1E3A5F', fontSize: '11px' }}>
            <div style={{ color: '#94A3B8' }}>
              <span style={{ color: '#F59E0B', fontWeight: 600 }}>ℹ️ Bilgi:</span> Açık vardiya verileri{' '}
              <span style={{ color: '#60A5FA', fontFamily: 'Roboto Mono, monospace' }}>{xmlPath}</span>{' '}
              adresinden çekilir. Kapalı vardiya verileri aynı klasördeki ZIP dosyalarından okunur.
              MSSQL bağlantısı için Ayarlar &gt; Veritabanı menüsünü kullanın.
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        {/* Canlı Satış Listesi */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="9" title="Canlı Satış Listesi" color="#22C55E" />
          <div style={{ overflowX: 'auto' }}>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Saat</th>
                  <th>Plaka</th>
                  <th>Pompa</th>
                  <th>Ürün</th>
                  <th className="text-right">Litre</th>
                  <th className="text-right">Tutar</th>
                  <th>Ödeme Tipi</th>
                  <th>Personel</th>
                </tr>
              </thead>
              <tbody>
                {satislar.map((s, i) => (
                  <tr key={i}>
                    <td className="mono" style={{ color: '#60A5FA', fontWeight: 600 }}>{s.saat}</td>
                    <td style={{ color: '#E2E8F0', fontWeight: 600 }}>{s.plaka}</td>
                    <td><span className="erp-badge-blue">{s.pompa}</span></td>
                    <td style={{ color: '#CBD5E1' }}>{s.urun}</td>
                    <td className="text-right mono" style={{ color: '#94A3B8' }}>{s.litre}</td>
                    <td className="text-right mono" style={{ color: '#22C55E', fontWeight: 600 }}>{s.tutar.toLocaleString('tr-TR')} ₺</td>
                    <td><span className={s.odemeTipi === 'Nakit' ? 'erp-badge-green' : 'erp-badge-blue'}>{s.odemeTipi}</span></td>
                    <td style={{ color: '#94A3B8', fontSize: '11px' }}>{s.personel}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pompa Durumu */}
        <div className="erp-panel" style={{ width: '200px', minWidth: '200px' }}>
          <PanelHeader num="9" title="Pompa Durumu" color="#3B82F6" />
          <div className="p-3">
            {pompalar.map((p, i) => (
              <div key={i} className="flex items-center justify-between mb-3 p-2 rounded"
                style={{ backgroundColor: '#0B1426', border: '1px solid #1E3A5F' }}>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: '#E2E8F0' }}>Pompa {p.no}</div>
                  <div style={{ fontSize: '10px', color: '#94A3B8' }}>{p.urun}</div>
                </div>
                <div className="flex items-center gap-1">
                  <div className="live-dot" />
                  <span style={{ fontSize: '10px', fontWeight: 700, color: '#22C55E' }}>AKTİF</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
