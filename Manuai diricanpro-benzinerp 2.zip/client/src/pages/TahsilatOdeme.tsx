import { useState } from "react";
import { cariler, tahsilatlar } from "@/lib/demoData";
import { toast } from "sonner";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function TahsilatOdeme() {
  const [activeTab, setActiveTab] = useState('tahsilat');
  const [selectedCari, setSelectedCari] = useState(cariler[0].id + ' - ' + cariler[0].ad);
  const [tutar, setTutar] = useState('');
  const [odemeTipi, setOdemeTipi] = useState('nakit');
  const [smsSend, setSmsSend] = useState(true);

  const handleKaydet = () => {
    if (!tutar) { toast.error('Tutar giriniz!'); return; }
    toast.success(`${activeTab === 'tahsilat' ? 'Tahsilat' : 'Ödeme'} kaydedildi: ${tutar} ₺`);
    setTutar('');
  };

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        {/* Tahsilat / Ödeme Formu */}
        <div className="erp-panel" style={{ width: '300px', minWidth: '300px' }}>
          <PanelHeader num="3" title="Tahsilat / Ödeme Kayıt" color="#22C55E" />
          <div className="p-3">
            {/* Tab */}
            <div className="flex gap-1 mb-3">
              {['tahsilat', 'odeme'].map(t => (
                <button key={t} onClick={() => setActiveTab(t)}
                  style={{
                    flex: 1, padding: '6px', borderRadius: '4px', border: 'none', cursor: 'pointer', fontSize: '12px', fontWeight: 700,
                    backgroundColor: activeTab === t ? (t === 'tahsilat' ? '#22C55E' : '#EF4444') : '#152642',
                    color: activeTab === t ? 'white' : '#94A3B8',
                  }}>
                  {t === 'tahsilat' ? 'Tahsilat' : 'Ödeme'}
                </button>
              ))}
            </div>

            <div className="flex flex-col gap-2">
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Cari *</label>
                <select className="erp-select w-full mt-1" value={selectedCari} onChange={e => setSelectedCari(e.target.value)}>
                  {cariler.map(c => (
                    <option key={c.id} value={c.id + ' - ' + c.ad}>{c.id} - {c.ad}</option>
                  ))}
                </select>
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tarih *</label>
                <input type="date" className="erp-input w-full mt-1" defaultValue="2025-05-18" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tutar *</label>
                <input type="number" className="erp-input w-full mt-1" placeholder="0,00" value={tutar}
                  onChange={e => setTutar(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Ödeme Tipi *</label>
                <div className="flex gap-1 mt-1">
                  {['nakit', 'visa', 'banka'].map(t => (
                    <button key={t} onClick={() => setOdemeTipi(t)}
                      style={{
                        flex: 1, padding: '4px', borderRadius: '3px', border: '1px solid #1E3A5F', cursor: 'pointer', fontSize: '10px', fontWeight: 600,
                        backgroundColor: odemeTipi === t ? '#1E6FD9' : '#0B1426',
                        color: odemeTipi === t ? 'white' : '#94A3B8',
                      }}>
                      {t === 'nakit' ? 'Nakit' : t === 'visa' ? 'Visa/Master' : 'Banka'}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Açıklama</label>
                <input type="text" className="erp-input w-full mt-1" placeholder="Akaryakıt ödeme tahsilatı" />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="sms" checked={smsSend} onChange={e => setSmsSend(e.target.checked)}
                  style={{ accentColor: '#1E6FD9' }} />
                <label htmlFor="sms" style={{ fontSize: '11px', color: '#94A3B8', cursor: 'pointer' }}>SMS Gönderilsin</label>
              </div>
              <div className="flex gap-2 mt-2">
                <button className="erp-btn-success" style={{ flex: 1 }} onClick={handleKaydet}>Kaydet</button>
                <button className="erp-btn-danger" style={{ flex: 1 }} onClick={() => setTutar('')}>Temizle</button>
              </div>
            </div>
          </div>
        </div>

        {/* Son İşlemler */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="3" title="Son Tahsilat / Ödeme İşlemleri" color="#3B82F6" />
          <div className="p-2">
            <div className="flex gap-2 mb-2">
              <input type="date" className="erp-input" defaultValue="2025-05-01" />
              <input type="date" className="erp-input" defaultValue="2025-05-18" />
              <select className="erp-select">
                <option value="">Tüm Cariler</option>
                {cariler.map(c => <option key={c.id}>{c.id} - {c.ad}</option>)}
              </select>
              <select className="erp-select">
                <option value="">Tüm Tipler</option>
                <option>Tahsilat</option>
                <option>Ödeme</option>
              </select>
              <button className="erp-btn-primary">Listele</button>
            </div>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Tarih</th>
                  <th>Cari</th>
                  <th>Tür</th>
                  <th className="text-right">Tutar</th>
                  <th>Ödeme Tipi</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody>
                {tahsilatlar.map((t, i) => (
                  <tr key={i}>
                    <td style={{ color: '#94A3B8' }}>{t.tarih}</td>
                    <td style={{ color: '#CBD5E1' }}>{cariler[i % cariler.length]?.ad}</td>
                    <td>
                      <span className={t.tur === 'Tahsilat' ? 'erp-badge-green' : 'erp-badge-red'}>{t.tur}</span>
                    </td>
                    <td className="text-right mono" style={{ color: t.tur === 'Tahsilat' ? '#22C55E' : '#EF4444', fontWeight: 600 }}>
                      {t.tutar.toLocaleString('tr-TR')} ₺
                    </td>
                    <td><span className="erp-badge-blue">{t.odemeTipi}</span></td>
                    <td>
                      <button onClick={() => toast.info('Silindi')} style={{ background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer', fontSize: '11px' }}>
                        Sil
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
