import { useState } from "react";
import { personeller } from "@/lib/demoData";
import { toast } from "sonner";
import { Plus, Edit, Trash2 } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function Personel() {
  const [showForm, setShowForm] = useState(false);
  const [ad, setAd] = useState('');
  const [gorev, setGorev] = useState('Pompa');
  const [telefon, setTelefon] = useState('');

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        {/* Personel Listesi */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="6" title="Personel Listesi" color="#8B5CF6">
            <button className="erp-btn-primary flex items-center gap-1" onClick={() => setShowForm(!showForm)}>
              <Plus size={12} />Yeni Personel
            </button>
          </PanelHeader>
          <div className="p-2">
            {showForm && (
              <div className="erp-card p-3 mb-3">
                <div style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', marginBottom: '8px' }}>YENİ PERSONEL EKLE</div>
                <div className="flex gap-2 flex-wrap">
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Ad Soyad *</label>
                    <input type="text" className="erp-input mt-1" placeholder="Ad Soyad" value={ad} onChange={e => setAd(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Görev *</label>
                    <select className="erp-select mt-1" value={gorev} onChange={e => setGorev(e.target.value)}>
                      <option>Pompa</option>
                      <option>Kasiyer</option>
                      <option>Vardiya Amiri</option>
                      <option>Müdür</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Telefon</label>
                    <input type="text" className="erp-input mt-1" placeholder="0532 xxx xx xx" value={telefon} onChange={e => setTelefon(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Giriş Tarihi</label>
                    <input type="date" className="erp-input mt-1" defaultValue="2025-05-18" />
                  </div>
                  <div className="flex items-end gap-2">
                    <button className="erp-btn-success" onClick={() => {
                      if (!ad) { toast.error('Ad Soyad giriniz!'); return; }
                      toast.success('Personel eklendi!');
                      setAd(''); setTelefon(''); setShowForm(false);
                    }}>Kaydet</button>
                    <button className="erp-btn-danger" onClick={() => setShowForm(false)}>İptal</button>
                  </div>
                </div>
              </div>
            )}
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Ad Soyad</th>
                  <th>Görev</th>
                  <th>Telefon</th>
                  <th>Giriş Tarihi</th>
                  <th>Durum</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody>
                {personeller.map((p, i) => (
                  <tr key={i}>
                    <td style={{ color: '#94A3B8' }}>{p.id}</td>
                    <td style={{ color: '#E2E8F0', fontWeight: 600 }}>{p.ad}</td>
                    <td><span className="erp-badge-blue">{p.gorev}</span></td>
                    <td style={{ color: '#94A3B8' }}>{p.telefon}</td>
                    <td style={{ color: '#94A3B8' }}>{p.girisTarihi}</td>
                    <td><span className={p.durum === 'Aktif' ? 'erp-badge-green' : 'erp-badge-red'}>{p.durum}</span></td>
                    <td>
                      <div className="flex gap-1">
                        <button onClick={() => toast.info('Düzenleniyor')} style={{ background: 'none', border: 'none', color: '#F59E0B', cursor: 'pointer' }}><Edit size={13} /></button>
                        <button onClick={() => toast.warning('Silindi')} style={{ background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}><Trash2 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Özet Kartlar */}
        <div className="flex flex-col gap-2" style={{ width: '200px', minWidth: '200px' }}>
          {[
            { label: 'Toplam Personel', value: personeller.length, color: '#3B82F6', icon: '👥' },
            { label: 'Aktif Personel', value: personeller.filter(p => p.durum === 'Aktif').length, color: '#22C55E', icon: '✅' },
            { label: 'Pompa Personeli', value: personeller.filter(p => p.gorev === 'Pompa').length, color: '#F59E0B', icon: '⛽' },
            { label: 'Vardiya Amiri', value: personeller.filter(p => p.gorev === 'Vardiya Amiri').length, color: '#8B5CF6', icon: '👔' },
          ].map((item, i) => (
            <div key={i} className="erp-stat-card">
              <div className="flex items-center gap-2">
                <span style={{ fontSize: '20px' }}>{item.icon}</span>
                <div>
                  <div style={{ fontSize: '9px', color: '#94A3B8', textTransform: 'uppercase' }}>{item.label}</div>
                  <div style={{ fontSize: '22px', fontWeight: 700, color: item.color }}>{item.value}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
