import { useState } from "react";
import { gelirGiderler } from "@/lib/demoData";
import { toast } from "sonner";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

const aylikData = [
  { ay: 'Oca', gelir: 180000, gider: 140000 },
  { ay: 'Şub', gelir: 195000, gider: 152000 },
  { ay: 'Mar', gelir: 210000, gider: 165000 },
  { ay: 'Nis', gelir: 225000, gider: 170000 },
  { ay: 'May', gelir: 245630, gider: 180000 },
];

export default function GelirGider() {
  const [tur, setTur] = useState('gelir');
  const [aciklama, setAciklama] = useState('');
  const [tutar, setTutar] = useState('');

  const toplamGelir = 5800;
  const toplamGider = 14200;
  const net = toplamGelir - toplamGider;

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        {/* Form */}
        <div className="erp-panel" style={{ width: '280px', minWidth: '280px' }}>
          <PanelHeader num="5" title="Gelir / Gider & Fatura" color="#22C55E" />
          <div className="p-3">
            <div className="flex gap-1 mb-3">
              {['gelir', 'gider'].map(t => (
                <button key={t} onClick={() => setTur(t)}
                  style={{
                    flex: 1, padding: '6px', borderRadius: '4px', border: 'none', cursor: 'pointer', fontSize: '12px', fontWeight: 700,
                    backgroundColor: tur === t ? (t === 'gelir' ? '#22C55E' : '#EF4444') : '#152642',
                    color: tur === t ? 'white' : '#94A3B8',
                  }}>
                  {t === 'gelir' ? 'Gelir' : 'Gider'}
                </button>
              ))}
            </div>
            <div className="flex flex-col gap-2">
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tür *</label>
                <select className="erp-select w-full mt-1">
                  {tur === 'gider' ? (
                    <>
                      <option>Elektrik Faturası</option>
                      <option>Su Faturası</option>
                      <option>Personel Maaş</option>
                      <option>Akaryakıt Alış</option>
                      <option>Kira</option>
                      <option>Diğer Gider</option>
                    </>
                  ) : (
                    <>
                      <option>Market Satış</option>
                      <option>Akaryakıt Satış</option>
                      <option>Diğer Gelir</option>
                    </>
                  )}
                </select>
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tarih *</label>
                <input type="date" className="erp-input w-full mt-1" defaultValue="2025-05-18" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Açıklama</label>
                <input type="text" className="erp-input w-full mt-1" placeholder="Açıklama giriniz"
                  value={aciklama} onChange={e => setAciklama(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tutar *</label>
                <input type="number" className="erp-input w-full mt-1" placeholder="0,00"
                  value={tutar} onChange={e => setTutar(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Belge No</label>
                <input type="text" className="erp-input w-full mt-1" placeholder="ELEK2025018" />
              </div>
              <div className="flex gap-2 mt-2">
                <button className="erp-btn-success" style={{ flex: 1 }}
                  onClick={() => { if (!tutar) { toast.error('Tutar giriniz!'); return; } toast.success('Kayıt eklendi!'); setTutar(''); }}>
                  Kaydet
                </button>
                <button className="erp-btn-danger" style={{ flex: 1 }} onClick={() => { setTutar(''); setAciklama(''); }}>
                  Temizle
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Kayıtlı İşlemler */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="5" title="Kayıtlı İşlemler" color="#F59E0B" />
          <div className="p-2">
            <div className="flex gap-2 mb-2">
              <input type="date" className="erp-input" defaultValue="2025-05-01" />
              <input type="date" className="erp-input" defaultValue="2025-05-18" />
              <select className="erp-select">
                <option value="">Tümü</option>
                <option>Gelir</option>
                <option>Gider</option>
              </select>
              <button className="erp-btn-primary">Listele</button>
            </div>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Tarih</th>
                  <th>Tür</th>
                  <th>Açıklama</th>
                  <th className="text-right">Tutar</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody>
                {gelirGiderler.map((g, i) => (
                  <tr key={i}>
                    <td style={{ color: '#94A3B8' }}>{g.tarih}</td>
                    <td><span className={g.tur === 'Gelir' ? 'erp-badge-green' : 'erp-badge-red'}>{g.tur}</span></td>
                    <td style={{ color: '#CBD5E1' }}>{g.aciklama}</td>
                    <td className="text-right mono" style={{ color: g.tur === 'Gelir' ? '#22C55E' : '#EF4444', fontWeight: 600 }}>
                      {g.tutar.toLocaleString('tr-TR')} ₺
                    </td>
                    <td>
                      <button onClick={() => toast.info('Silindi')} style={{ background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer', fontSize: '11px' }}>
                        Sil
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{ borderTop: '1px solid #1E3A5F', paddingTop: '8px', marginTop: '4px' }}>
              <div className="flex gap-4">
                <div>
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>Toplam Gelir</span>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: '#22C55E', fontFamily: 'Roboto Mono, monospace' }}>
                    {toplamGelir.toLocaleString('tr-TR')} ₺
                  </div>
                </div>
                <div>
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>Toplam Gider</span>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: '#EF4444', fontFamily: 'Roboto Mono, monospace' }}>
                    {toplamGider.toLocaleString('tr-TR')} ₺
                  </div>
                </div>
                <div>
                  <span style={{ fontSize: '10px', color: '#94A3B8' }}>Net</span>
                  <div style={{ fontSize: '14px', fontWeight: 700, color: net >= 0 ? '#22C55E' : '#EF4444', fontFamily: 'Roboto Mono, monospace' }}>
                    {net.toLocaleString('tr-TR')} ₺
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Aylık Grafik */}
      <div className="erp-panel">
        <PanelHeader num="📊" title="Aylık Gelir / Gider Grafiği" color="#3B82F6" />
        <div className="p-3">
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={aylikData} margin={{ top: 4, right: 16, bottom: 0, left: 0 }}>
              <XAxis dataKey="ay" tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ backgroundColor: '#152642', border: '1px solid #1E3A5F', fontSize: '11px', color: '#E2E8F0' }}
                formatter={(v: any) => [v.toLocaleString('tr-TR') + ' ₺']}
              />
              <Legend wrapperStyle={{ fontSize: '11px', color: '#94A3B8' }} />
              <Bar dataKey="gelir" name="Gelir" fill="#22C55E" radius={[3, 3, 0, 0]} />
              <Bar dataKey="gider" name="Gider" fill="#EF4444" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
