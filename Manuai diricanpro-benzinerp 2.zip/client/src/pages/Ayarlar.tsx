import { useState } from "react";
import { toast } from "sonner";
import { Save, Database, Wifi, Building2, Bell } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function Ayarlar() {
  const [activeTab, setActiveTab] = useState('istasyon');
  const [dbServer, setDbServer] = useState('10.102.24.10');
  const [dbName, setDbName] = useState('AkaryakitDB');
  const [dbUser, setDbUser] = useState('sa');
  const [dbPass, setDbPass] = useState('');
  const [xmlPath, setXmlPath] = useState('\\\\10.102.24.10\\Shift\\Sale.xml');

  const tabs = [
    { id: 'istasyon', label: 'İstasyon Bilgileri', icon: Building2 },
    { id: 'veritabani', label: 'Veritabanı', icon: Database },
    { id: 'xml', label: 'XML / Otomasyon', icon: Wifi },
    { id: 'bildirim', label: 'Bildirimler', icon: Bell },
  ];

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        {/* Sidebar Tabs */}
        <div className="erp-panel" style={{ width: '180px', minWidth: '180px' }}>
          <PanelHeader num="⚙️" title="Ayarlar" color="#6B7280" />
          <div className="p-2">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className="flex items-center gap-2 w-full rounded mb-1"
                style={{
                  padding: '8px 10px', border: 'none', cursor: 'pointer', fontSize: '12px', textAlign: 'left',
                  backgroundColor: activeTab === t.id ? '#1E3A5F' : 'transparent',
                  color: activeTab === t.id ? '#60A5FA' : '#94A3B8',
                  fontWeight: activeTab === t.id ? 600 : 400,
                }}>
                <t.icon size={14} />
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="erp-panel" style={{ flex: 1 }}>
          {activeTab === 'istasyon' && (
            <>
              <PanelHeader num="🏪" title="İstasyon Bilgileri" color="#1E6FD9" />
              <div className="p-4">
                <div className="flex flex-col gap-3" style={{ maxWidth: '480px' }}>
                  {[
                    { label: 'İstasyon Adı', defaultValue: 'DiricanPro Akaryakıt' },
                    { label: 'Vergi No', defaultValue: '1234567890' },
                    { label: 'Adres', defaultValue: 'Örnek Mah. Örnek Cad. No:1' },
                    { label: 'Telefon', defaultValue: '0532 123 45 67' },
                    { label: 'E-posta', defaultValue: 'info@diricanpro.com' },
                    { label: 'Lisans Kodu', defaultValue: 'DEMO-2025-XXXX' },
                  ].map((f, i) => (
                    <div key={i}>
                      <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>{f.label}</label>
                      <input type="text" className="erp-input w-full" defaultValue={f.defaultValue} />
                    </div>
                  ))}
                  <button className="erp-btn-success flex items-center gap-1 mt-2" style={{ width: 'fit-content' }}
                    onClick={() => toast.success('İstasyon bilgileri kaydedildi!')}>
                    <Save size={13} />Kaydet
                  </button>
                </div>
              </div>
            </>
          )}

          {activeTab === 'veritabani' && (
            <>
              <PanelHeader num="🗄️" title="Veritabanı Bağlantısı (MSSQL)" color="#3B82F6" />
              <div className="p-4">
                <div className="p-3 rounded mb-4" style={{ backgroundColor: '#0B1426', border: '1px solid #1E3A5F', fontSize: '11px', color: '#94A3B8' }}>
                  <span style={{ color: '#F59E0B', fontWeight: 600 }}>⚠️ Not:</span> MSSQL bağlantısı kurulduktan sonra veriler otomatik olarak PostgreSQL'e aktarılacaktır.
                  Bayilik sisteminde her bayi kendi veritabanı ile çalışır.
                </div>
                <div className="flex flex-col gap-3" style={{ maxWidth: '480px' }}>
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>Sunucu Adresi</label>
                    <input type="text" className="erp-input w-full" value={dbServer} onChange={e => setDbServer(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>Veritabanı Adı</label>
                    <input type="text" className="erp-input w-full" value={dbName} onChange={e => setDbName(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>Kullanıcı Adı</label>
                    <input type="text" className="erp-input w-full" value={dbUser} onChange={e => setDbUser(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>Şifre</label>
                    <input type="password" className="erp-input w-full" value={dbPass} onChange={e => setDbPass(e.target.value)} placeholder="••••••••" />
                  </div>
                  <div className="flex gap-2">
                    <button className="erp-btn-primary flex items-center gap-1"
                      onClick={() => toast.info('Bağlantı test ediliyor...')}>
                      <Wifi size={13} />Bağlantıyı Test Et
                    </button>
                    <button className="erp-btn-success flex items-center gap-1"
                      onClick={() => toast.success('Veritabanı ayarları kaydedildi!')}>
                      <Save size={13} />Kaydet
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'xml' && (
            <>
              <PanelHeader num="📡" title="XML / Otomasyon Ayarları" color="#22C55E" />
              <div className="p-4">
                <div className="flex flex-col gap-3" style={{ maxWidth: '480px' }}>
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>Açık Vardiya XML Yolu</label>
                    <input type="text" className="erp-input w-full" value={xmlPath} onChange={e => setXmlPath(e.target.value)} />
                    <div style={{ fontSize: '10px', color: '#94A3B8', marginTop: '4px' }}>
                      Örnek: \\10.102.24.10\Shift\Sale.xml
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>Kapalı Vardiya ZIP Klasörü</label>
                    <input type="text" className="erp-input w-full" defaultValue="\\10.102.24.10\Shift\" />
                    <div style={{ fontSize: '10px', color: '#94A3B8', marginTop: '4px' }}>
                      Kapalı vardiya ZIP dosyaları bu klasörden okunur
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>Otomatik Yenileme (saniye)</label>
                    <input type="number" className="erp-input" defaultValue="15" style={{ width: '100px' }} />
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" id="autoSync" defaultChecked style={{ accentColor: '#1E6FD9' }} />
                    <label htmlFor="autoSync" style={{ fontSize: '11px', color: '#94A3B8', cursor: 'pointer' }}>
                      Otomatik senkronizasyon aktif
                    </label>
                  </div>
                  <button className="erp-btn-success flex items-center gap-1" style={{ width: 'fit-content' }}
                    onClick={() => toast.success('XML ayarları kaydedildi!')}>
                    <Save size={13} />Kaydet
                  </button>
                </div>
              </div>
            </>
          )}

          {activeTab === 'bildirim' && (
            <>
              <PanelHeader num="🔔" title="Bildirim Ayarları" color="#F59E0B" />
              <div className="p-4">
                <div className="flex flex-col gap-3" style={{ maxWidth: '480px' }}>
                  {[
                    { label: 'Tank doluluk uyarısı (%30 altı)', defaultChecked: true },
                    { label: 'Veresiye limit uyarısı', defaultChecked: true },
                    { label: 'Günlük satış raporu SMS', defaultChecked: false },
                    { label: 'Vardiya kapanış bildirimi', defaultChecked: true },
                    { label: 'Kasa fark uyarısı', defaultChecked: true },
                  ].map((n, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked={n.defaultChecked} style={{ accentColor: '#1E6FD9' }} />
                      <label style={{ fontSize: '12px', color: '#CBD5E1', cursor: 'pointer' }}>{n.label}</label>
                    </div>
                  ))}
                  <div>
                    <label style={{ fontSize: '11px', color: '#94A3B8', display: 'block', marginBottom: '4px' }}>SMS Gönderim Numarası</label>
                    <input type="text" className="erp-input w-full" placeholder="0532 xxx xx xx" />
                  </div>
                  <button className="erp-btn-success flex items-center gap-1" style={{ width: 'fit-content' }}
                    onClick={() => toast.success('Bildirim ayarları kaydedildi!')}>
                    <Save size={13} />Kaydet
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
