import { useState } from "react";
import { cariler } from "@/lib/demoData";
import { toast } from "sonner";
import { Plus, Eye, Printer, Download } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

const faturalar = [
  { no: 'FAT-2025-001', tarih: '18.05.2025', cari: 'YILDIRIM NAKLİYAT', urun: 'MOTORİN', litre: 500, birimFiyat: 32.5, tutar: 16250, kdv: 2925, toplam: 19175, durum: 'Ödendi' },
  { no: 'FAT-2025-002', tarih: '17.05.2025', cari: 'KARTAL İNŞAAT', urun: 'MOTORİN', litre: 300, birimFiyat: 32.5, tutar: 9750, kdv: 1755, toplam: 11505, durum: 'Bekliyor' },
  { no: 'FAT-2025-003', tarih: '17.05.2025', cari: 'ANADOLU LOJİSTİK', urun: 'LPG', litre: 400, birimFiyat: 20, tutar: 8000, kdv: 1440, toplam: 9440, durum: 'Kısmi' },
  { no: 'FAT-2025-004', tarih: '16.05.2025', cari: 'GÜNEŞ TAŞIMACILIK', urun: 'MOTORİN', litre: 200, birimFiyat: 32.5, tutar: 6500, kdv: 1170, toplam: 7670, durum: 'Ödendi' },
  { no: 'FAT-2025-005', tarih: '15.05.2025', cari: 'BARAN TİCARET', urun: 'BENZİN', litre: 150, birimFiyat: 38.3, tutar: 5745, kdv: 1034, toplam: 6779, durum: 'Bekliyor' },
];

export default function Faturalar() {
  const [selectedFatura, setSelectedFatura] = useState<any>(null);

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="📄" title="Faturalar" color="#1E6FD9">
            <button className="erp-btn-primary flex items-center gap-1" onClick={() => toast.info('Yeni fatura oluşturuluyor')}>
              <Plus size={12} />Yeni Fatura
            </button>
          </PanelHeader>
          <div className="p-2">
            <div className="flex gap-2 mb-2">
              <input type="date" className="erp-input" defaultValue="2025-05-01" />
              <input type="date" className="erp-input" defaultValue="2025-05-18" />
              <select className="erp-select">
                <option value="">Tüm Cariler</option>
                {cariler.map(c => <option key={c.id}>{c.ad}</option>)}
              </select>
              <select className="erp-select">
                <option value="">Tüm Durumlar</option>
                <option>Ödendi</option>
                <option>Bekliyor</option>
                <option>Kısmi</option>
              </select>
              <button className="erp-btn-primary">Listele</button>
            </div>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Fatura No</th>
                  <th>Tarih</th>
                  <th>Cari</th>
                  <th>Ürün</th>
                  <th className="text-right">Litre</th>
                  <th className="text-right">Tutar</th>
                  <th className="text-right">KDV</th>
                  <th className="text-right">Toplam</th>
                  <th>Durum</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody>
                {faturalar.map((f, i) => (
                  <tr key={i} style={{ cursor: 'pointer', backgroundColor: selectedFatura?.no === f.no ? '#1a2e4a' : undefined }}
                    onClick={() => setSelectedFatura(f)}>
                    <td style={{ color: '#60A5FA', fontWeight: 600 }}>{f.no}</td>
                    <td style={{ color: '#94A3B8' }}>{f.tarih}</td>
                    <td style={{ color: '#CBD5E1' }}>{f.cari}</td>
                    <td style={{ color: '#94A3B8' }}>{f.urun}</td>
                    <td className="text-right mono" style={{ color: '#94A3B8' }}>{f.litre}</td>
                    <td className="text-right mono" style={{ color: '#E2E8F0' }}>{f.tutar.toLocaleString('tr-TR')} ₺</td>
                    <td className="text-right mono" style={{ color: '#94A3B8' }}>{f.kdv.toLocaleString('tr-TR')} ₺</td>
                    <td className="text-right mono" style={{ color: '#22C55E', fontWeight: 700 }}>{f.toplam.toLocaleString('tr-TR')} ₺</td>
                    <td>
                      <span className={f.durum === 'Ödendi' ? 'erp-badge-green' : f.durum === 'Bekliyor' ? 'erp-badge-red' : 'erp-badge-yellow'}>
                        {f.durum}
                      </span>
                    </td>
                    <td>
                      <div className="flex gap-1">
                        <button onClick={() => toast.info('Fatura görüntüleniyor')} style={{ background: 'none', border: 'none', color: '#60A5FA', cursor: 'pointer' }}><Eye size={13} /></button>
                        <button onClick={() => toast.info('Yazdırılıyor')} style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer' }}><Printer size={13} /></button>
                        <button onClick={() => toast.info('İndiriliyor')} style={{ background: 'none', border: 'none', color: '#22C55E', cursor: 'pointer' }}><Download size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={5} style={{ fontWeight: 700, color: '#E2E8F0', fontSize: '11px' }}>Toplam</td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#E2E8F0' }}>
                    {faturalar.reduce((s, f) => s + f.tutar, 0).toLocaleString('tr-TR')} ₺
                  </td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#94A3B8' }}>
                    {faturalar.reduce((s, f) => s + f.kdv, 0).toLocaleString('tr-TR')} ₺
                  </td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#22C55E' }}>
                    {faturalar.reduce((s, f) => s + f.toplam, 0).toLocaleString('tr-TR')} ₺
                  </td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
