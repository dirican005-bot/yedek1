import { useState } from "react";
import { toast } from "sonner";
import { Plus, Edit, Trash2, Shield } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

const kullanicilar = [
  { id: 1, kullaniciAdi: 'admin', ad: 'Sistem Yöneticisi', rol: 'Admin', email: 'admin@diricanpro.com', sonGiris: '18.05.2025 14:25', durum: 'Aktif' },
  { id: 2, kullaniciAdi: 'ahmet.yilmaz', ad: 'Ahmet YILMAZ', rol: 'Pompa Personeli', email: 'ahmet@diricanpro.com', sonGiris: '18.05.2025 06:05', durum: 'Aktif' },
  { id: 3, kullaniciAdi: 'mehmet.kaya', ad: 'Mehmet KAYA', rol: 'Pompa Personeli', email: 'mehmet@diricanpro.com', sonGiris: '17.05.2025 22:10', durum: 'Aktif' },
  { id: 4, kullaniciAdi: 'caner.sahin', ad: 'Caner ŞAHİN', rol: 'Vardiya Amiri', email: 'caner@diricanpro.com', sonGiris: '18.05.2025 08:30', durum: 'Aktif' },
  { id: 5, kullaniciAdi: 'fatma.yildiz', ad: 'Fatma YILDIZ', rol: 'Kasiyer', email: 'fatma@diricanpro.com', sonGiris: '18.05.2025 09:00', durum: 'Aktif' },
];

const roller = ['Admin', 'Vardiya Amiri', 'Kasiyer', 'Pompa Personeli', 'Muhasebe', 'Sadece Görüntüleme'];

const rolRenkleri: Record<string, string> = {
  'Admin': '#EF4444',
  'Vardiya Amiri': '#F59E0B',
  'Kasiyer': '#22C55E',
  'Pompa Personeli': '#3B82F6',
  'Muhasebe': '#8B5CF6',
  'Sadece Görüntüleme': '#6B7280',
};

export default function Kullanicilar() {
  const [showForm, setShowForm] = useState(false);

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div className="flex gap-2">
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="👤" title="Kullanıcı Yönetimi" color="#8B5CF6">
            <button className="erp-btn-primary flex items-center gap-1" onClick={() => setShowForm(!showForm)}>
              <Plus size={12} />Yeni Kullanıcı
            </button>
          </PanelHeader>
          <div className="p-2">
            {showForm && (
              <div className="erp-card p-3 mb-3">
                <div style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', marginBottom: '8px' }}>YENİ KULLANICI EKLE</div>
                <div className="flex gap-2 flex-wrap">
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Ad Soyad *</label>
                    <input type="text" className="erp-input mt-1" placeholder="Ad Soyad" />
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Kullanıcı Adı *</label>
                    <input type="text" className="erp-input mt-1" placeholder="kullanici.adi" />
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>E-posta</label>
                    <input type="email" className="erp-input mt-1" placeholder="email@ornek.com" />
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Şifre *</label>
                    <input type="password" className="erp-input mt-1" placeholder="••••••••" />
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', color: '#94A3B8' }}>Rol *</label>
                    <select className="erp-select mt-1">
                      {roller.map(r => <option key={r}>{r}</option>)}
                    </select>
                  </div>
                  <div className="flex items-end gap-2">
                    <button className="erp-btn-success" onClick={() => { toast.success('Kullanıcı eklendi!'); setShowForm(false); }}>Kaydet</button>
                    <button className="erp-btn-danger" onClick={() => setShowForm(false)}>İptal</button>
                  </div>
                </div>
              </div>
            )}

            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Kullanıcı Adı</th>
                  <th>Ad Soyad</th>
                  <th>Rol</th>
                  <th>E-posta</th>
                  <th>Son Giriş</th>
                  <th>Durum</th>
                  <th>İşlem</th>
                </tr>
              </thead>
              <tbody>
                {kullanicilar.map((k, i) => (
                  <tr key={i}>
                    <td style={{ color: '#94A3B8' }}>{k.id}</td>
                    <td style={{ color: '#60A5FA', fontWeight: 600, fontFamily: 'Roboto Mono, monospace' }}>{k.kullaniciAdi}</td>
                    <td style={{ color: '#E2E8F0', fontWeight: 500 }}>{k.ad}</td>
                    <td>
                      <span style={{
                        backgroundColor: (rolRenkleri[k.rol] || '#6B7280') + '22',
                        color: rolRenkleri[k.rol] || '#6B7280',
                        border: `1px solid ${(rolRenkleri[k.rol] || '#6B7280')}44`,
                        fontSize: '10px', padding: '1px 6px', borderRadius: '3px', fontWeight: 600,
                      }}>
                        {k.rol}
                      </span>
                    </td>
                    <td style={{ color: '#94A3B8' }}>{k.email}</td>
                    <td style={{ color: '#94A3B8' }}>{k.sonGiris}</td>
                    <td><span className="erp-badge-green">{k.durum}</span></td>
                    <td>
                      <div className="flex gap-1">
                        <button onClick={() => toast.info('Düzenleniyor')} style={{ background: 'none', border: 'none', color: '#F59E0B', cursor: 'pointer' }}><Edit size={13} /></button>
                        <button onClick={() => toast.info('Yetkiler düzenleniyor')} style={{ background: 'none', border: 'none', color: '#8B5CF6', cursor: 'pointer' }}><Shield size={13} /></button>
                        <button onClick={() => toast.warning('Silindi')} style={{ background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}><Trash2 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Rol Yetkileri */}
        <div className="erp-panel" style={{ width: '260px', minWidth: '260px' }}>
          <PanelHeader num="🔐" title="Rol Yetkileri" color="#EF4444" />
          <div className="p-2">
            {roller.map((r, i) => (
              <div key={i} className="flex items-center justify-between mb-2 p-2 rounded"
                style={{ backgroundColor: '#0B1426', border: '1px solid #1a2e4a' }}>
                <span style={{
                  fontSize: '11px', fontWeight: 600,
                  color: rolRenkleri[r] || '#6B7280',
                }}>
                  {r}
                </span>
                <button onClick={() => toast.info(`${r} yetkileri düzenleniyor`)}
                  style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer', fontSize: '10px' }}>
                  Düzenle
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
