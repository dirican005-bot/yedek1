import { useState, useEffect } from "react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import {
  demoStats, urunDagilim, haftalikSatis, tahsilatDurumu, odemeTipleri,
  pompalar, tanklar, canliSatislar, hizliIstatistik, formatTutar, formatLitre
} from "@/lib/demoData";
import { TrendingUp, TrendingDown, RefreshCw, X } from "lucide-react";

const StatCard = ({ label, value, sub, icon, color, trend }: any) => (
  <div className="erp-stat-card flex items-center gap-3" style={{ flex: 1, minWidth: 0 }}>
    <div className="flex items-center justify-center rounded-lg" style={{ backgroundColor: color + '22', width: '44px', height: '44px', minWidth: '44px' }}>
      <span style={{ fontSize: '22px' }}>{icon}</span>
    </div>
    <div style={{ minWidth: 0 }}>
      <div style={{ fontSize: '10px', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: '17px', fontWeight: 700, color: '#E2E8F0', fontFamily: 'Roboto Condensed, sans-serif', lineHeight: 1.2 }}>{value}</div>
      {sub && (
        <div className="flex items-center gap-1" style={{ fontSize: '10px', color: trend > 0 ? '#22C55E' : '#EF4444' }}>
          {trend > 0 ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
          {sub}
        </div>
      )}
    </div>
  </div>
);

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F',
    borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{
        backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700,
        padding: '1px 6px', borderRadius: '3px', minWidth: '20px', textAlign: 'center'
      }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

const TankBar = ({ tank }: any) => {
  const pct = tank.yuzde;
  const barColor = pct < 30 ? '#EF4444' : pct < 50 ? '#F59E0B' : '#22C55E';
  return (
    <div className="flex items-center gap-2 mb-1.5">
      <div style={{ fontSize: '10px', color: '#94A3B8', width: '52px', minWidth: '52px' }}>{tank.no}</div>
      <div style={{ fontSize: '10px', color: '#CBD5E1', width: '52px', minWidth: '52px' }}>{tank.urun}</div>
      <div style={{ flex: 1, height: '14px', backgroundColor: '#0B1426', borderRadius: '3px', overflow: 'hidden', border: '1px solid #1E3A5F' }}>
        <div style={{ width: `${pct}%`, height: '100%', backgroundColor: barColor, borderRadius: '2px', transition: 'width 0.5s' }} />
      </div>
      <div style={{ fontSize: '10px', color: barColor, fontWeight: 700, width: '30px', textAlign: 'right' }}>{pct}%</div>
      <div style={{ fontSize: '10px', color: '#94A3B8', width: '60px', textAlign: 'right', fontFamily: 'Roboto Mono, monospace' }}>
        {tank.stok.toLocaleString('tr-TR')} LT
      </div>
    </div>
  );
};

export default function Dashboard() {
  const [liveTime, setLiveTime] = useState(new Date().toLocaleTimeString('tr-TR'));
  const [canliData, setCanliData] = useState(canliSatislar);

  useEffect(() => {
    const timer = setInterval(() => {
      setLiveTime(new Date().toLocaleTimeString('tr-TR'));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>

      {/* Stat Cards Row */}
      <div className="flex gap-2">
        <StatCard label="Günlük Satış Tutarı" value={formatTutar(demoStats.gunlukSatisTutari)}
          sub={`Dün: ${formatTutar(demoStats.oncekiGunSatisTutari)} · %23,71 ↑`} icon="💰" color="#22C55E" trend={1} />
        <StatCard label="Günlük Satış Litre" value={formatLitre(demoStats.gunlukSatisLitre)}
          sub={`Dün: ${formatLitre(demoStats.oncekiGunSatisLitre)} · %26,41 ↑`} icon="⛽" color="#3B82F6" trend={1} />
        <StatCard label="Veresiye Toplam Borç" value={formatTutar(demoStats.veresiyeToplam)}
          sub={`Cari Sayısı: ${demoStats.cariSayisi}`} icon="📋" color="#F59E0B" trend={-1} />
        <StatCard label="Nakit Kasa Bakiye" value={formatTutar(demoStats.nakitKasaBakiye)}
          sub={`Banka: ${formatTutar(demoStats.bankaBakiye)}`} icon="🏦" color="#8B5CF6" trend={1} />
        <StatCard label="Günün İşlem Sayısı" value={demoStats.gunlukIslemSayisi.toString()}
          sub="Dün: 215 · %33,02 ↑" icon="📊" color="#06B6D4" trend={1} />
      </div>

      {/* Row 2: Charts */}
      <div className="flex gap-2">
        {/* Ürün Dağılım Pie */}
        <div className="erp-panel" style={{ flex: '0 0 260px' }}>
          <PanelHeader num="📊" title="Ürün Satış Dağılımı (Litre)" color="#3B82F6" />
          <div className="p-2">
            <div className="flex items-center gap-2">
              <ResponsiveContainer width={120} height={110}>
                <PieChart>
                  <Pie data={urunDagilim} dataKey="litre" cx="50%" cy="50%" innerRadius={30} outerRadius={52} paddingAngle={2}>
                    {urunDagilim.map((entry, i) => (
                      <Cell key={i} fill={entry.renk} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '16px', fontWeight: 700, color: '#E2E8F0', fontFamily: 'Roboto Condensed, sans-serif' }}>
                  {formatLitre(demoStats.gunlukSatisLitre)}
                </div>
                <div style={{ fontSize: '9px', color: '#94A3B8', marginBottom: '4px' }}>TOPLAM LT</div>
                {urunDagilim.map((u, i) => (
                  <div key={i} className="flex items-center justify-between" style={{ fontSize: '10px', marginBottom: '2px' }}>
                    <div className="flex items-center gap-1">
                      <div style={{ width: '8px', height: '8px', borderRadius: '2px', backgroundColor: u.renk }} />
                      <span style={{ color: '#CBD5E1' }}>{u.urun}</span>
                    </div>
                    <span style={{ color: '#94A3B8', fontFamily: 'Roboto Mono, monospace' }}>{u.litre.toLocaleString('tr-TR')} LT</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Haftalık Bar Chart */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="📈" title="Son 7 Gün Satış Grafiği (Tutar)" color="#22C55E" />
          <div className="p-2">
            <ResponsiveContainer width="100%" height={110}>
              <BarChart data={haftalikSatis} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
                <XAxis dataKey="gun" tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip
                  contentStyle={{ backgroundColor: '#152642', border: '1px solid #1E3A5F', fontSize: '11px', color: '#E2E8F0' }}
                  formatter={(v: any) => [formatTutar(v), 'Tutar']}
                />
                <Bar dataKey="tutar" fill="#1E6FD9" radius={[3, 3, 0, 0]}>
                  {haftalikSatis.map((_, i) => (
                    <Cell key={i} fill={i === haftalikSatis.length - 1 ? '#22C55E' : '#1E6FD9'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tahsilat Durumu Pie */}
        <div className="erp-panel" style={{ flex: '0 0 220px' }}>
          <PanelHeader num="💳" title="Tahsilat Durumu" color="#F59E0B" />
          <div className="p-2">
            <div className="flex items-center gap-2">
              <ResponsiveContainer width={90} height={90}>
                <PieChart>
                  <Pie data={tahsilatDurumu} dataKey="tutar" cx="50%" cy="50%" innerRadius={25} outerRadius={42} paddingAngle={2}>
                    {tahsilatDurumu.map((entry, i) => (
                      <Cell key={i} fill={entry.renk} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '15px', fontWeight: 700, color: '#E2E8F0', fontFamily: 'Roboto Condensed, sans-serif' }}>
                  {formatTutar(demoStats.veresiyeToplam)}
                </div>
                <div style={{ fontSize: '9px', color: '#94A3B8', marginBottom: '4px' }}>TOPLAM BORÇ</div>
                {tahsilatDurumu.map((t, i) => (
                  <div key={i} className="flex items-center justify-between" style={{ fontSize: '10px', marginBottom: '2px' }}>
                    <div className="flex items-center gap-1">
                      <div style={{ width: '8px', height: '8px', borderRadius: '2px', backgroundColor: t.renk }} />
                      <span style={{ color: '#CBD5E1' }}>{t.aralik}</span>
                    </div>
                    <span style={{ color: '#94A3B8', fontFamily: 'Roboto Mono, monospace' }}>{t.tutar.toLocaleString('tr-TR')} ₺</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Ödeme Tipleri + Pompa Tablosu + Tank Stok */}
      <div className="flex gap-2">
        {/* Ödeme Tipleri */}
        <div className="erp-panel" style={{ flex: '0 0 220px' }}>
          <PanelHeader num="💵" title="Ödeme Tipleri (Bugün)" color="#8B5CF6" />
          <div className="p-2">
            {odemeTipleri.map((o, i) => (
              <div key={i} className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span style={{ fontSize: '14px' }}>{o.ikon}</span>
                  <span style={{ fontSize: '11px', color: '#CBD5E1' }}>{o.tip}</span>
                </div>
                <div className="text-right">
                  <div style={{ fontSize: '12px', fontWeight: 700, color: '#E2E8F0', fontFamily: 'Roboto Mono, monospace' }}>
                    {o.tutar.toLocaleString('tr-TR')} ₺
                  </div>
                  <div style={{ fontSize: '10px', color: '#94A3B8' }}>%{o.yuzde.toFixed(2)}</div>
                </div>
              </div>
            ))}
            <div style={{ borderTop: '1px solid #1E3A5F', paddingTop: '6px', marginTop: '4px' }}>
              <div className="flex justify-between">
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0' }}>TOPLAM</span>
                <span style={{ fontSize: '12px', fontWeight: 700, color: '#22C55E', fontFamily: 'Roboto Mono, monospace' }}>
                  {formatTutar(demoStats.gunlukSatisTutari)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Pompa Satış Tablosu */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="⛽" title="Pompa Satış Tablosu (Bugün)" color="#06B6D4" />
          <div className="p-2">
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Pompa</th>
                  <th>Ürün</th>
                  <th className="text-right">Litre</th>
                  <th className="text-right">Tutar</th>
                </tr>
              </thead>
              <tbody>
                {pompalar.map((p, i) => (
                  <tr key={i}>
                    <td><span className="erp-badge-blue">{p.no}</span></td>
                    <td style={{ color: '#CBD5E1' }}>{p.urun}</td>
                    <td className="text-right mono" style={{ color: '#94A3B8' }}>{p.litre.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</td>
                    <td className="text-right mono" style={{ color: '#22C55E', fontWeight: 600 }}>{p.tutar.toLocaleString('tr-TR')} ₺</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={2} style={{ fontWeight: 700, color: '#E2E8F0', fontSize: '11px' }}>TOPLAM</td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#E2E8F0' }}>
                    {pompalar.reduce((s, p) => s + p.litre, 0).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="text-right mono" style={{ fontWeight: 700, color: '#22C55E' }}>
                    {pompalar.reduce((s, p) => s + p.tutar, 0).toLocaleString('tr-TR')} ₺
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Tank Stok */}
        <div className="erp-panel" style={{ flex: '0 0 280px' }}>
          <PanelHeader num="🛢️" title="Tank Stok Durumu" color="#F59E0B" />
          <div className="p-2">
            {tanklar.map((t, i) => <TankBar key={i} tank={t} />)}
          </div>
        </div>
      </div>

      {/* Row 4: Canlı Satış + Hızlı İstatistik */}
      <div className="flex gap-2">
        {/* Canlı Satış */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="" title="" color="#22C55E">
            <div className="flex items-center gap-2">
              <div className="live-dot" />
              <span style={{ fontSize: '11px', fontWeight: 700, color: '#22C55E' }}>CANLI SATIŞ (SON 10 İŞLEM)</span>
              <button className="erp-btn-primary flex items-center gap-1" style={{ padding: '2px 8px', fontSize: '10px' }}>
                <RefreshCw size={10} /> Yenile
              </button>
              <button style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer' }}>
                <X size={14} />
              </button>
            </div>
          </PanelHeader>
          <div style={{ overflowX: 'auto' }}>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Saat</th>
                  <th>Plaka</th>
                  <th>Pompa</th>
                  <th>Ürün</th>
                  <th className="text-right">Litre</th>
                  <th className="text-right">Tutar</th>
                  <th>Ödeme Tipi</th>
                  <th>Personel</th>
                </tr>
              </thead>
              <tbody>
                {canliData.map((s, i) => (
                  <tr key={i}>
                    <td className="mono" style={{ color: '#60A5FA', fontWeight: 600 }}>{s.saat}</td>
                    <td style={{ color: '#E2E8F0', fontWeight: 600 }}>{s.plaka}</td>
                    <td><span className="erp-badge-blue">{s.pompa}</span></td>
                    <td style={{ color: '#CBD5E1' }}>{s.urun}</td>
                    <td className="text-right mono" style={{ color: '#94A3B8' }}>{s.litre}</td>
                    <td className="text-right mono" style={{ color: '#22C55E', fontWeight: 600 }}>{s.tutar.toLocaleString('tr-TR')} ₺</td>
                    <td>
                      <span className={s.odemeTipi === 'Nakit' ? 'erp-badge-green' : 'erp-badge-blue'}>
                        {s.odemeTipi}
                      </span>
                    </td>
                    <td style={{ color: '#94A3B8', fontSize: '11px' }}>{s.personel}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Hızlı İstatistik */}
        <div className="erp-panel" style={{ flex: '0 0 220px' }}>
          <PanelHeader num="⚡" title="Hızlı İstatistik" color="#8B5CF6" />
          <div className="p-2">
            {[
              { label: 'Ortalama Litre / Satış', value: hizliIstatistik.ortalamaLitreSatis + ' LT' },
              { label: 'Ortalama Tutar / Satış', value: hizliIstatistik.ortalamaTutarSatis + ' ₺' },
              { label: 'En Çok Satılan Ürün', value: hizliIstatistik.enCokSatilanUrun },
              { label: 'En Çok Satan Pompa', value: '0' + hizliIstatistik.enCokSatanPompa },
              { label: 'En Yoğun Saat', value: hizliIstatistik.enYogunSaat },
              { label: 'Toplam Müşteri (Bugün)', value: hizliIstatistik.toplamMusteriGun.toString() },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between mb-2 pb-2" style={{ borderBottom: i < 5 ? '1px solid #1a2e4a' : 'none' }}>
                <span style={{ fontSize: '10px', color: '#94A3B8' }}>{item.label}</span>
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', fontFamily: 'Roboto Mono, monospace' }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
