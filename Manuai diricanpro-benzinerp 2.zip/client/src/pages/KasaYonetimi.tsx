import { kasaHareketleri } from "@/lib/demoData";
import { toast } from "sonner";
import { Plus } from "lucide-react";

const PanelHeader = ({ num, title, color = '#1E6FD9', children }: any) => (
  <div className="flex items-center justify-between px-2 py-1.5" style={{
    background: `linear-gradient(90deg, ${color}22 0%, #152642 100%)`,
    borderBottom: '1px solid #1E3A5F', borderRadius: '4px 4px 0 0',
  }}>
    <div className="flex items-center gap-2">
      <span style={{ backgroundColor: color, color: 'white', fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: '3px' }}>{num}</span>
      <span style={{ fontSize: '11px', fontWeight: 700, color: '#E2E8F0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</span>
    </div>
    <div className="flex items-center gap-1">{children}</div>
  </div>
);

export default function KasaYonetimi() {
  const kasaBakiyeleri = [
    { tip: 'NAKİT', bakiye: 50000, color: '#22C55E' },
    { tip: 'VİSA/MASTER', bakiye: 30000, color: '#3B82F6' },
    { tip: 'BANKA', bakiye: 25000, color: '#8B5CF6' },
    { tip: 'ÇEK', bakiye: 5000, color: '#F59E0B' },
  ];

  const toplam = kasaBakiyeleri.reduce((s, k) => s + k.bakiye, 0);

  return (
    <div style={{ padding: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {/* Kasa Özeti */}
      <div className="flex gap-2">
        {kasaBakiyeleri.map((k, i) => (
          <div key={i} className="erp-stat-card" style={{ flex: 1 }}>
            <div style={{ fontSize: '10px', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '4px' }}>{k.tip}</div>
            <div style={{ fontSize: '18px', fontWeight: 700, color: k.color, fontFamily: 'Roboto Mono, monospace' }}>
              {k.bakiye.toLocaleString('tr-TR')} ₺
            </div>
          </div>
        ))}
        <div className="erp-stat-card" style={{ flex: 1 }}>
          <div style={{ fontSize: '10px', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '4px' }}>TOPLAM</div>
          <div style={{ fontSize: '18px', fontWeight: 700, color: '#E2E8F0', fontFamily: 'Roboto Mono, monospace' }}>
            {toplam.toLocaleString('tr-TR')} ₺
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        {/* Para Çekme/Yatırma */}
        <div className="erp-panel" style={{ width: '260px', minWidth: '260px' }}>
          <PanelHeader num="7" title="Para Hareketi" color="#22C55E" />
          <div className="p-3">
            <div className="flex gap-1 mb-3">
              <button className="erp-btn-success" style={{ flex: 1 }} onClick={() => toast.success('Para yatırıldı!')}>Para Yatır</button>
              <button className="erp-btn-danger" style={{ flex: 1 }} onClick={() => toast.warning('Para çekildi!')}>Para Çek</button>
            </div>
            <div className="flex flex-col gap-2">
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Kasa Tipi</label>
                <select className="erp-select w-full mt-1">
                  <option>Nakit</option>
                  <option>Visa/Master</option>
                  <option>Banka</option>
                  <option>Çek</option>
                </select>
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tutar</label>
                <input type="number" className="erp-input w-full mt-1" placeholder="0,00" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Açıklama</label>
                <input type="text" className="erp-input w-full mt-1" placeholder="Açıklama giriniz" />
              </div>
              <div>
                <label style={{ fontSize: '10px', color: '#94A3B8' }}>Tarih</label>
                <input type="date" className="erp-input w-full mt-1" defaultValue="2025-05-18" />
              </div>
              <button className="erp-btn-primary w-full mt-1" onClick={() => toast.success('Kayıt eklendi!')}>Kaydet</button>
            </div>
          </div>
        </div>

        {/* Kasa Hareketleri */}
        <div className="erp-panel" style={{ flex: 1 }}>
          <PanelHeader num="7" title="Kasa Hareketleri" color="#3B82F6">
            <button className="erp-btn-primary flex items-center gap-1" onClick={() => toast.info('Yeni hareket')}>
              <Plus size={12} />Yeni
            </button>
          </PanelHeader>
          <div className="p-2">
            <div className="flex gap-2 mb-2">
              <input type="date" className="erp-input" defaultValue="2025-05-01" />
              <input type="date" className="erp-input" defaultValue="2025-05-18" />
              <select className="erp-select">
                <option value="">Tüm Tipler</option>
                <option>Giriş</option>
                <option>Çıkış</option>
              </select>
              <button className="erp-btn-primary">Listele</button>
            </div>
            <table className="erp-table w-full">
              <thead>
                <tr>
                  <th>Tarih</th>
                  <th>Tür</th>
                  <th>Açıklama</th>
                  <th className="text-right">Giriş</th>
                  <th className="text-right">Çıkış</th>
                  <th className="text-right">Bakiye</th>
                  <th>Kullanıcı</th>
                </tr>
              </thead>
              <tbody>
                {kasaHareketleri.map((h, i) => (
                  <tr key={i}>
                    <td style={{ color: '#94A3B8' }}>{h.tarih}</td>
                    <td><span className={h.tur === 'Giriş' ? 'erp-badge-green' : 'erp-badge-red'}>{h.tur}</span></td>
                    <td style={{ color: '#CBD5E1' }}>{h.aciklama}</td>
                    <td className="text-right mono" style={{ color: h.giris > 0 ? '#22C55E' : '#94A3B8' }}>
                      {h.giris > 0 ? h.giris.toLocaleString('tr-TR') + ' ₺' : '-'}
                    </td>
                    <td className="text-right mono" style={{ color: h.cikis > 0 ? '#EF4444' : '#94A3B8' }}>
                      {h.cikis > 0 ? h.cikis.toLocaleString('tr-TR') + ' ₺' : '-'}
                    </td>
                    <td className="text-right mono" style={{ color: '#E2E8F0', fontWeight: 600 }}>
                      {h.bakiye.toLocaleString('tr-TR')} ₺
                    </td>
                    <td style={{ color: '#94A3B8' }}>{h.kullanici}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
