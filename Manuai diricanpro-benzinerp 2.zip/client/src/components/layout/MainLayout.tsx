import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, Clock, CreditCard, Users, TrendingUp, FileText,
  UserCheck, Wallet, Database, Activity, BarChart3, Settings,
  UserCog, LogOut, Menu, X, Fuel, MessageSquare, Bell, ChevronRight
} from "lucide-react";

const navItems = [
  { path: "/", label: "Ana Sayfa", icon: LayoutDashboard },
  { path: "/vardiyalar", label: "Vardiyalar", icon: Clock },
  { path: "/tahsilat", label: "Tahsilat / Ödeme", icon: CreditCard },
  { path: "/cari", label: "Cari / Veresiye", icon: Users },
  { path: "/gelir-gider", label: "Gelir / Gider", icon: TrendingUp },
  { path: "/faturalar", label: "Faturalar", icon: FileText },
  { path: "/personel", label: "Personel", icon: UserCheck },
  { path: "/kasa", label: "Kasa Yönetimi", icon: Wallet },
  { path: "/stok", label: "Stok / Tanklar", icon: Database },
  { path: "/canli-satis", label: "Canlı Satış (XML)", icon: Activity },
  { path: "/raporlar", label: "Raporlar", icon: BarChart3 },
  { path: "/ayarlar", label: "Ayarlar", icon: Settings },
  { path: "/kullanicilar", label: "Kullanıcılar", icon: UserCog },
];

const now = new Date();
const tarihStr = now.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' });
const gunStr = now.toLocaleDateString('tr-TR', { weekday: 'long' });

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentTime] = useState(() => {
    const d = new Date();
    return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  });

  return (
    <div className="flex h-screen overflow-hidden" style={{ backgroundColor: '#0B1426', color: '#E2E8F0' }}>
      {/* Sidebar */}
      <aside
        className="flex flex-col transition-all duration-200"
        style={{
          width: sidebarOpen ? '220px' : '56px',
          minWidth: sidebarOpen ? '220px' : '56px',
          backgroundColor: '#080F1E',
          borderRight: '1px solid #1E3A5F',
          overflow: 'hidden',
        }}
      >
        {/* Logo */}
        <div className="flex items-center gap-2 px-3 py-3" style={{ borderBottom: '1px solid #1E3A5F', minHeight: '52px' }}>
          <div className="flex items-center justify-center rounded" style={{ backgroundColor: '#1E6FD9', width: '32px', height: '32px', minWidth: '32px' }}>
            <Fuel size={18} color="white" />
          </div>
          {sidebarOpen && (
            <div>
              <div style={{ fontSize: '13px', fontWeight: 700, color: '#E2E8F0', fontFamily: 'Roboto Condensed, sans-serif', lineHeight: 1.1 }}>
                DiricanPro
              </div>
              <div style={{ fontSize: '10px', color: '#60A5FA', fontWeight: 600, letterSpacing: '0.08em' }}>
                BENZİNERP
              </div>
            </div>
          )}
        </div>

        {/* Nav Items */}
        <nav className="flex-1 overflow-y-auto py-2 scrollbar-thin" style={{ overflowX: 'hidden' }}>
          {navItems.map(({ path, label, icon: Icon }) => {
            const isActive = location === path;
            return (
              <Link key={path} href={path}>
                <div
                  className="flex items-center gap-2 mx-1 my-0.5 rounded transition-all duration-150"
                  style={{
                    padding: sidebarOpen ? '7px 10px' : '7px',
                    justifyContent: sidebarOpen ? 'flex-start' : 'center',
                    backgroundColor: isActive ? '#1E3A5F' : 'transparent',
                    color: isActive ? '#60A5FA' : '#94A3B8',
                    fontWeight: isActive ? 600 : 400,
                    fontSize: '12.5px',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={e => {
                    if (!isActive) {
                      (e.currentTarget as HTMLElement).style.backgroundColor = '#152642';
                      (e.currentTarget as HTMLElement).style.color = '#CBD5E1';
                    }
                  }}
                  onMouseLeave={e => {
                    if (!isActive) {
                      (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent';
                      (e.currentTarget as HTMLElement).style.color = '#94A3B8';
                    }
                  }}
                >
                  <Icon size={15} style={{ minWidth: '15px', color: isActive ? '#1E6FD9' : 'inherit' }} />
                  {sidebarOpen && <span>{label}</span>}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Logout */}
        <div style={{ borderTop: '1px solid #1E3A5F', padding: '8px' }}>
          <div
            className="flex items-center gap-2 rounded transition-all duration-150"
            style={{
              padding: sidebarOpen ? '7px 10px' : '7px',
              justifyContent: sidebarOpen ? 'flex-start' : 'center',
              color: '#EF4444',
              fontSize: '12.5px',
              cursor: 'pointer',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(239,68,68,0.1)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
          >
            <LogOut size={15} />
            {sidebarOpen && <span>Çıkış</span>}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Header */}
        <header
          className="flex items-center justify-between px-3"
          style={{
            backgroundColor: '#0B1426',
            borderBottom: '1px solid #1E3A5F',
            minHeight: '52px',
            gap: '8px',
          }}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="rounded p-1.5 transition-colors"
              style={{ color: '#94A3B8', backgroundColor: 'transparent' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.backgroundColor = '#152642'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
            >
              {sidebarOpen ? <X size={16} /> : <Menu size={16} />}
            </button>
            <span style={{ fontSize: '13px', color: '#94A3B8' }}>
              Hoş geldiniz, <span style={{ color: '#E2E8F0', fontWeight: 600 }}>Admin</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-colors"
              style={{ backgroundColor: '#1E6FD9', color: 'white', border: 'none' }}>
              <MessageSquare size={13} />
              SMS Gönder
            </button>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-colors"
              style={{ backgroundColor: '#152642', color: '#94A3B8', border: '1px solid #1E3A5F' }}>
              <Bell size={13} />
              Yedekle
            </button>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-colors"
              style={{ backgroundColor: '#152642', color: '#94A3B8', border: '1px solid #1E3A5F' }}>
              <Settings size={13} />
              Ayarlar
            </button>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded"
              style={{ backgroundColor: '#152642', border: '1px solid #1E3A5F', fontSize: '11px', color: '#94A3B8' }}>
              <span style={{ color: '#E2E8F0', fontWeight: 600 }}>{tarihStr}</span>
              <span>{gunStr}</span>
              <span style={{ color: '#60A5FA', fontWeight: 700, fontFamily: 'Roboto Mono, monospace' }}>{currentTime}</span>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto scrollbar-thin" style={{ backgroundColor: '#0B1426' }}>
          {children}
        </main>
      </div>
    </div>
  );
}
