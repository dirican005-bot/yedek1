# DiricanPro BenzinERP - Tasarım Konsepti

## Seçilen Tasarım: "Industrial Command Center"

### Design Movement
Endüstriyel Kontrol Merkezi - Petrol & Enerji sektörüne özgü, güçlü ve güvenilir bir kurumsal ERP arayüzü.

### Core Principles
1. **Koyu Lacivert Otorite** - Koyu lacivert (#0B1426) ana arka plan, profesyonel ve güvenilir his
2. **Veri Yoğunluğu** - Maksimum bilgi yoğunluğu, kompakt ama okunabilir layout
3. **Renk Kodlu Durum** - Yeşil (aktif/pozitif), Kırmızı (uyarı/negatif), Turuncu (bekleyen), Mavi (nötr/bilgi)
4. **Hiyerarşik Panel Sistemi** - Numaralı paneller, her modül kendi kartında

### Color Philosophy
- **Ana Arka Plan**: #0B1426 (derin lacivert) - güç ve güven
- **Panel Arka Plan**: #0F1E35 (koyu mavi) - derinlik
- **Kart Arka Plan**: #152642 (orta mavi) - ayrım
- **Vurgu Mavi**: #1E6FD9 (parlak mavi) - aksiyon
- **Başarı Yeşil**: #22C55E - pozitif değerler
- **Uyarı Kırmızı**: #EF4444 - negatif/uyarı
- **Turuncu**: #F59E0B - bekleyen işlemler
- **Metin**: #E2E8F0 (açık gri) - okunabilirlik

### Layout Paradigm
- Sol sabit sidebar (240px) - navigasyon
- Üst header bar - kullanıcı bilgisi, tarih, hızlı aksiyonlar
- Ana içerik: CSS Grid ile çoklu panel düzeni (görseldeki gibi)
- Her panel numaralı ve başlıklı kart yapısında

### Signature Elements
1. **Pompa İkonu** - Yakıt pompası SVG ikonu logo olarak
2. **Canlı Göstergeler** - Yeşil yanıp sönen nokta ile "CANLI" etiketi
3. **Progress Bar Tank Göstergeleri** - Renkli doluluk çubukları

### Typography System
- **Başlık**: Roboto Condensed Bold - kompakt ve güçlü
- **Veri**: Roboto Mono - sayısal veriler için monospace
- **Gövde**: Roboto Regular - okunabilir arayüz metni
- **Küçük Etiket**: Roboto 10-11px - yoğun veri alanları
